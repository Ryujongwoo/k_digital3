function tableAdd() {
//	데이터가 입력된 form을 얻어와서 form에 입력된 데이터를 배열에 저장한다.
//	let form = document.getElementsByTagName('form')[0]
//	let form = document.querySelectorAll('form')[0]
//	forms: 현재 문서의 form을 배열 형태로 저장하고 있는 자바스크립트 객체
//	console.log(document.forms)
	let form = document.forms[0]
	console.log(form)
	
//	let id = document.getElementsByName('id')[0].value
//	console.log('id: ' + id)

//	form이저장된변수.name속성값.value: form에서 지정된 name 속성을 가지는 요소에 입력된 값을
//	얻어올 수 있다.
	console.log('id: ' + form.id.value)
	console.log('password: ' + form.password.value)
	console.log('address: ' + form.address.value)
	console.log('phoneNumber: ' + form.phoneNumber.value)

}


































