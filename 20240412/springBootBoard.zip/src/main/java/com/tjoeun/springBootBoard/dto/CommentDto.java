package com.tjoeun.springBootBoard.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CommentDto { // 댓글 1건을 기억하는 클래스

	private Long id;
	private Long articleId;
	private String nickname;
	private String body;
	
//	Comment 엔티티를 CommentDto로 변환하는 메소드
	
	
}
