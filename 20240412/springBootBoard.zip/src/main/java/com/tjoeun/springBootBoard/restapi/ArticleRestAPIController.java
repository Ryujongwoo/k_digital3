package com.tjoeun.springBootBoard.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.repository.ArticleRepository;
import com.tjoeun.springBootBoard.service.ArticleService;

import lombok.extern.slf4j.Slf4j;

//	@RestController 어노테이션은 RestAPI용 컨트롤러로 사용됨을 의미한다.
//	viewpage가 아닌 JSON 타입의 데이터를 리턴한다.
@RestController
@Slf4j
public class ArticleRestAPIController {

//	@Autowired
//	private ArticleRepository articleRepository;
//	ArticleRestAPIController에서 사용하던 ArticleRepository를 Service 계층으로 넘겨서 사용하기 위해
//	ArticleRestAPIController에서는 ArticleService 객체를 통해 ArticleRepository에 접근해 사용한다.
	@Autowired // @Service 어노테이션을 붙여서 선언한 객체의 bean을 springBoot가 자동으로 초기화 한다.
	private ArticleService articleService;
	
//	Article 테이블 전체 글 조회
	@GetMapping("/restapi/articles") // CRUD => Read, sql => select
	public List<Article> index() {
		log.info("ArticleRestAPIController의 index() 메소드 실행");
		return articleService.index();
	}
	
//	Article 테이블 특정 글 조회
	@GetMapping("/restapi/articles/{id}")
	public Article show(@PathVariable Long id) {
		log.info("ArticleRestAPIController의 show() 메소드 실행");
		return articleService.show(id);
	}
	
//	Article 테이블에 글 1건 저장
	@PostMapping("/restapi/articles") // CRUD => Create, sql => insert
//	form에서 데이터를 받아올 때는 커맨드 객체로 받으면 되지만 RestAPI에서 JSON으로 던지는 데이터를
//	받을 때는 BODY 부분에 담겨서 넘어오는 데이터를 받아야 하므로 데이터를 받을 커맨드 객체 앞에
//	@RequestBody 어노테이션을 붙여서 받아야 한다.
//	http 상태 코드를 리턴하려면 ResponseEntity 클래스 객체를 사용해야 한다.
//	ResponseEntity<Article>를 리턴 타입으로 사용하면 ResponseEntity 객체에 Article 객체를 담아서 리턴한다.
	public ResponseEntity<Article> create(@RequestBody ArticleForm articleForm) {
		log.info("ArticleRestAPIController의 create() 메소드 실행");
//		log.info("articleForm = " + articleForm);
		Article saved = articleService.create(articleForm);
//		return saved;
//		정상적으로 저장했으면 정상 응답(HttpStatus.CREATED: 201)을 보내고 저장에 실패했으면 잘못된
//		요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
		return saved != null ?
			ResponseEntity.status(HttpStatus.CREATED).body(saved) : 
//			ResponseEntity.status(HttpStatus.BAD_REQUEST).body(saved);
//			body() 메소드는 body에 데이터를 담아서 넘기고 build() 메소드는 body 없이 넘긴다.
			ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
//	Article 테이블의 글 1건 수정
	@PatchMapping("/restapi/articles/{id}") // CRUD => Update, sql => update
	public ResponseEntity<Article> update(@PathVariable Long id, @RequestBody ArticleForm articleForm) {
		log.info("ArticleRestAPIController의 update() 메소드 실행");
		/*
		log.info("id = {}, articleForm = {}", id, articleForm);
//		수정할 데이터가 저장된 엔티티 객체를 생성한다.
		Article article = articleForm.toEntity();
		log.info("id = {}, article = {}", id, article);
//		수정할 엔티티를 조회한다.
		Article target = articleRepository.findById(id).orElse(null);
		log.info("id = {}, target = {}", id, target);
//		잘못된 요청(수정할 id에 해당되는 글이 없거나 id가 다를 경우)을 처리한다.
		if (target == null || id != target.getId()) {
			log.info("잘못된 요청!!!");
//			잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
//		수정 후 정상 응답(HttpStatus.OK: 200)을 보낸다.
//		if (article.getTitle() != null) {
//			target.setTitle(article.getTitle());
//		}
//		if (article.getContent() != null) {
//			target.setContent(article.getContent());
//		}
		target.patch(article);
		*/
		Article updated = articleService.update(id, articleForm);
//		정상적으로 수정했으면 정상 응답(HttpStatus.OK: 200)을 보내고 수정에 실패했으면 잘못된
//		요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
		return updated != null ?
			ResponseEntity.status(HttpStatus.OK).body(updated) :
			ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
//	Article 테이블의 글 1건 삭제
	@DeleteMapping("/restapi/articles/{id}") // CRUD => Delete, sql => delete
	public ResponseEntity<Article> delete(@PathVariable Long id) {
		log.info("ArticleRestAPIController의 delete() 메소드 실행");
		/*
//		삭제할 엔티티를 조회한다.
		Article target = articleRepository.findById(id).orElse(null);
		log.info("id = {}, target = {}", id, target);
//		잘못된 요청(삭제할 id에 해당되는 글이 없을 경우)을 처리한다.
		if (target == null) {
			log.info("잘못된 요청!!!");
//			잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
		*/
//		정상적으로 삭제했으면 정상 응답(HttpStatus.NO_CONTENT: 204)을 보내고 삭제에 실패했으면
//		잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
		Article deleted = articleService.delete(id);
		return deleted != null ? 
			ResponseEntity.status(HttpStatus.NO_CONTENT).body(deleted) :
			ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
//	트랜잭션
	@PostMapping("/restapi/transaction")
	public ResponseEntity<List<Article>> transaction(@RequestBody List<ArticleForm> articleForms) {
		log.info("ArticleRestAPIController의 transaction() 메소드 실행");
//		log.info("articleForms = {}", articleForms);
		List<Article> createList = articleService.createArticles(articleForms);
		return createList != null ?
			ResponseEntity.status(HttpStatus.OK).body(createList) :
			ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); 
	}
	
}





