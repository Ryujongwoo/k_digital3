package com.tjoeun.springBootBoard.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Comment { // 댓글 테이블

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne // 댓글 엔티티 여러개가 메인글 1개와 연관된다.
//	별도의 설정이 없으면 외래키 필드의 이름은 참조하는 테이블 이름과 참조하는 테이블의 기본키 필드의
//	이름을 "_"로 연결해서 만들어준다. => article_id
//	외래키 필드 이름을 직접 지정하려면 @JoinColumn 어노테이션의 name 속성에 별도로 지정할 외래키의
//	이름을 지정하면 된다.
	@JoinColumn(name = "article_id")
//	comment 테이블에는 article_id 필드가 추가되고 article 테이블의 기본키 필드 값이 저장된다.
	private Article article;
	
	@Column
	private String nickname;
	@Column
	private String body;
	
}
