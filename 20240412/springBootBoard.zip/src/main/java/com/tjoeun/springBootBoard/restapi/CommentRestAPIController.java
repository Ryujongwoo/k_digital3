package com.tjoeun.springBootBoard.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.tjoeun.springBootBoard.dto.CommentDto;
import com.tjoeun.springBootBoard.entity.Comment;
import com.tjoeun.springBootBoard.service.CommentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CommentRestAPIController {

//	CommentService 클래스의 멤소드를 사용하기 위해 CommentService 클래스의 bean을 얻어온다.
	@Autowired
	private CommentService commentService;
	
//	특정 메인글 id에 따른 댓글 목록 조회
//	Talend API Tester(GET) => http://localhost:9090/restapi/comments/1
	@GetMapping("/restapi/comments/{articleId}")
	public ResponseEntity<List<Comment>> comments(@PathVariable Long articleId) {
		log.info("CommentRestAPIController의 comments() 메소드 실행");
		log.info("articleId = {}", articleId);
//		서비스에 위임
		List<Comment> comments = commentService.comments(articleId);
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(comments);
	}
	
}
