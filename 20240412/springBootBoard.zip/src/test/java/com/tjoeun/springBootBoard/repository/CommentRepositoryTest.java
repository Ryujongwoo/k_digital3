package com.tjoeun.springBootBoard.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.entity.Comment;

//	@SpringBootTest 어노테이션은 full application config을 로드해서 통합 테스트를 실행한다.
//	@DataJpaTest 어노테이션은 JPA 컴포넌트들만을 대상으로 테스트를 실행한다.
//	@SpringBootTest 어노테이션을 붙여주면 springBoot와 연동한 통합 테스트를 수행할 수 있고
//	@DataJpaTest 어노테이션을 붙여주면 JPA와 연동한 테스트를 수행할 수 있다.
@DataJpaTest
class CommentRepositoryTest {

	@Autowired
	private CommentRepository commentRepository;
	
	@Test
//	@DisplayName 어노테이션은 JUnit 실행 결과에 메소드 이름 대신 출력할 테스트 제목을 지정한다.
	@DisplayName("특정 메인글의 모든 댓글 조회")
	void testFindByArticlaId() {
//		1번 메인글의 모든 댓글 조회 => 댓글 있음
		{
			Long articleId = 1L;
//			예상
			Article article = new Article(1L, "당신의 인생 드라마는?", "댓글");
			Comment comment1 = new Comment(1L, article, "홍길동", "태양의 후예");
			Comment comment2 = new Comment(2L, article, "임꺽정", "태왕 사신기");
			Comment comment3 = new Comment(3L, article, "장길산", "응답하라 1994");
			List<Comment> expected = Arrays.asList(comment1, comment2, comment3);
			System.out.println("expected = " + expected);
//			실제
			List<Comment> actual = commentRepository.findByArticlaId(articleId);
			System.out.println("actual = " + actual);
//			비교
			assertEquals(expected.toString(), actual.toString(), "1번 메인글의 모든 댓글 조회");
		}
		
//		4번 메인글의 모든 댓글 조회 => 댓글 없음
		{
			Long articleId = 4L;
			List<Comment> expected = Arrays.asList();
			List<Comment> actual = commentRepository.findByArticlaId(articleId);
			assertEquals(expected.toString(), actual.toString(), "4번 메인글의 모든 댓글 조회");
		}
	}

	@Test
	@DisplayName("특정 닉네임의 모든 댓글 조회")
	void testFindByNickname() {
//		홍길동 닉네임의 모든 댓글 조회 => 댓글 있음
		{
			String nickname = "홍길동";
//			예상
			Comment comment1 = new Comment(1L, new Article(1L, "당신의 인생 드라마는?", "댓글"), nickname, "태양의 후예");
			Comment comment2 = new Comment(4L, new Article(2L, "당신의 소울 푸드는?", "댓글"), nickname, "초밥");
			Comment comment3 = new Comment(7L, new Article(3L, "당신의 취미는?", "댓글"), nickname, "등산");
			List<Comment> expected = Arrays.asList(comment1, comment2, comment3);
			System.out.println("expected = " + expected);
//			실제
			List<Comment> actual = commentRepository.findByNickname(nickname);
			System.out.println("actual = " + actual);
//			비교
			assertEquals(expected.toString(), actual.toString(), "닉네임이 홍길동인 모든 댓글 조회");
		}
		
//		일지매 닉네임의 모든 댓글 조회 => 댓글 없음
		{
			String nickname = "일지매";
			List<Comment> expected = Arrays.asList();
			List<Comment> actual = commentRepository.findByNickname(nickname);
			assertEquals(expected.toString(), actual.toString(), "닉네임이 일지매인 모든 댓글 조회");
		}
	}

}














