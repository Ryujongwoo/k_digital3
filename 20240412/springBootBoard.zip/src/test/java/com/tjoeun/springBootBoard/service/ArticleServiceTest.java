package com.tjoeun.springBootBoard.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;

//	@SpringBootTest 어노테이션을 붙여서 springBoot와 연동한 통합 테스트를 수행한다.
@SpringBootTest
class ArticleServiceTest {

	@Autowired
	private ArticleService articleService;
	
//	article 테이블 전체 목록 조회 테스트
	@Test
	void testIndex() {
//		index() 메소드가 실행되었을 때 예상되는 결과를 만든다.
		Article article1 = new Article(1L, "홍길동", "천재");
		Article article2 = new Article(2L, "임꺽정", "처언재");
		Article article3 = new Article(3L, "장길산", "처어언재");
		List<Article> expected = new ArrayList<Article>(Arrays.asList(article1, article2, article3));
//		index() 메소드가 실제로 실행되었을 때 결과를 얻어온다.
		List<Article> actual = articleService.index();
//		예상되는 결과와 실제로 실행되었을 때 결과를 비교한다.
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 단일 목록 조회 테스트 => 성공시
	@Test
	void testShow_성공시_존재하는_id가_입력된_경우() {
//		예상
		Article expected = new Article(1L, "홍길동", "천재");
//		실제
		Article actual = articleService.show(1L);
//		비교
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 단일 목록 조회 테스트 => 실패시
	@Test
	void testShow_실패시_존재하지_않는_id가_입력된_경우() {
//		예상
		Article expected = null;
//		실제
		Article actual = articleService.show(-1L);
//		비교
		assertEquals(expected, actual);
	}
	
//	article 테이블 글 저장 테스트 => 성공시
	@Test
//	테스트 메소드에 @Transactional 어노테이션을 붙여주면 테스트 종로 후 변경된 데이터를 rollback 처리한다.
	@Transactional
	void testCreate_성공시_id가_포함되지_않은_글_저장() {
//		예상
		String title = "손오공";
		String content = "제천대성";
		Article expected = new Article(4L, title, content);
//		실제
		Article actual = articleService.create(new ArticleForm(null, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 글 저장 테스트 => 실패시
	@Test
	@Transactional
	void testCreate_성공시_id가_포함된_글_저장() {
//		예상
		String title = "손오공";
		String content = "제천대성";
		Article expected = null;
//		실제
		Article actual = articleService.create(new ArticleForm(4L, title, content));
//		비교
		assertEquals(expected, actual);
	}
	
//	article 테이블 글 수정 테스트 => 성공시
	@Test
	@Transactional
	void testUpdate_성공시_존재하는_id와_title_content가_있는_수정() {
//		예상
		Long id = 3L;
		String title = "손오공";
		String content = "제천대성";
		Article expected = new Article(id, title, content);
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}

	@Test
	@Transactional
	void testUpdate_성공시_존재하는_id와_title만_있는_수정() {
//		예상
		Long id = 3L;
		String title = "손오공";
		String content = null;
		Article expected = new Article(id, title, "처어언재");
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
	@Test
	@Transactional
	void testUpdate_성공시_존재하는_id와_content만_있는_수정() {
//		예상
		Long id = 3L;
		String title = null;
		String content = "바보";
		Article expected = new Article(id, "장길산", content);
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
//	article 테이블 글 수정 테스트 => 실패시
	@Test
	@Transactional
	void testUpdate_실패시_존재하지_않는_id가_있는_수정() {
//		예상
		Long id = 4L;
		String title = "홍길동";
		String content = "바보";
		Article expected = null;
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected, actual);
	}
	
	@Test
	@Transactional
	void testUpdate_실패시_id는_존재하는데_title_content가_없는_수정() {
//		예상
		Long id = 3L;
		String title = null;
		String content = null;
		Article expected = null;
//		실제
		Article actual = articleService.update(id, new ArticleForm(id, title, content));
//		비교
		assertEquals(expected, actual);
	}
	
//	article 테이블 글 삭제 테스트 => 성공시
	@Test
	@Transactional
	void testDelete_성공시_존재하는_id() {
//		예상
		Long id = 3L;
		String title = "장길산";
		String content = "처어언재";
		Article expected = new Article(id, title, content);
//		실제
		Article actual = articleService.delete(id);
//		비교
		assertEquals(expected.toString(), actual.toString());
	}

//	article 테이블 글 삭제 테스트 => 실패시
	@Test
	@Transactional
	void testDelete_실패시_존재하지_않는_id() {
//		예상
		Long id = 4L;
		String title = "장길산";
		String content = "처어언재";
		Article expected = null;
//		실제
		Article actual = articleService.delete(id);
//		비교
		assertEquals(expected, actual);
	}
	
}








