package com.tjoeun.genericTest2;

public abstract class Material {

	abstract void doPrinting();
	
}
