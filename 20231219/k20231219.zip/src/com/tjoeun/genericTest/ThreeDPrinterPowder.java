package com.tjoeun.genericTest;

//	재료로 powder를 사용하는 3D 프린터, powder 전용 프린터
public class ThreeDPrinterPowder {

	private Powder material;

	public Powder getMaterial() {
		return material;
	}
	public void setMaterial(Powder material) {
		this.material = material;
	}
	
}
