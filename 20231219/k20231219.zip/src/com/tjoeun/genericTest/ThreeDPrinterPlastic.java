package com.tjoeun.genericTest;

//	재료로 plastic를 사용하는 3D 프린터, plastic 전용 프린터
public class ThreeDPrinterPlastic {

	private Plastic material;

	public Plastic getMaterial() {
		return material;
	}
	public void setMaterial(Plastic material) {
		this.material = material;
	}
	
}
