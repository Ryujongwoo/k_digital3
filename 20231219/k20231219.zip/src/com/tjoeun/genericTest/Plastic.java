package com.tjoeun.genericTest;

//	3D 프린터 재료 - plastic
public class Plastic {

	@Override
	public String toString() {
		return "Plastic";
	}

}
