package com.tjoeun.genericTest;

//	3D 프린터 재료 - powder
public class Powder {

	@Override
	public String toString() {
		return "Powder";
	}
	
}
