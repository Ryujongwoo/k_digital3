package com.tjoeun.genericTest3;

public class ThreeDPrinterTest {

	public static void main(String[] args) {
		
		GenericPrinter<Powder> genericPrinter = new GenericPrinter<Powder>();
		genericPrinter.setMaterial(new Powder());
		System.out.println(genericPrinter.getMaterial());
		Powder powder = genericPrinter.getMaterial();
		
		GenericPrinter<Plastic> genericPrinter2 = new GenericPrinter<Plastic>();
		genericPrinter2.setMaterial(new Plastic());
		System.out.println(genericPrinter2.getMaterial());
		Plastic plastic = genericPrinter2.getMaterial();
		System.out.println("=======================================");
		
//		GenericPrinter의 제네릭으로 넘기는 Water 클래스는 Material 클래스를 상속받아 작성되지 않아서
//		에러가 발생된다.
//		GenericPrinter<Water> genericPrinter3 = new GenericPrinter<Water>(); // 에러 발생
		
	}
	
}




















