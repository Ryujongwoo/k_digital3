package com.tjoeun.genericTest3;

//	3D 프린터 재료 - water
public class Water {

	@Override
	public String toString() {
		return "Water";
	}

}
