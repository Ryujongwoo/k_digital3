package com.tjoeun.springBootJPA.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.tjoeun.springBootJPA.domain.Member;

import jakarta.persistence.GeneratedValue;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberRepositoryTest {

//	MemberRepository를 테스트할 것이므로 MemberRepository 인터페이스 객체를 springBoot가 자동으로
//	초기화할 수 있도록 @Autowired 어노테이션을 붙여서 선언한다.
	@Autowired
	private MemberRepository memberRepository;
	
//	특정 테스트만 실행하려면 실행할 테스트 메소드에서 ctrl + F11을 눌러 실행하면 된다.
	@Test
	void test() {
		System.out.println("MemberRepositoryTest 클래스의 test() 메소드 실행");
		
//		코드상에서 @Entity 어노테이션을 붙여서 클래스로 선언해서 만들어진 테이블에 데이터를 넣을때는
//		@GeneratedValue 어노테이션으로 기본키 값 증가 정책 IDENTITY, SEQUENCE, TABLE, AUTO 중 어느것으로
//		설정되어 있어도 기본키 값이 잘 증가한다.
		
//		memberRepository.save(new Member("손오공", "hong@tjoeun.com"));
//		memberRepository.save(new Member("임꺽정", "lim@tjoeun.com"));
//		memberRepository.save(new Member("장길산", "jang@tjoeun.com"));
//		memberRepository.save(new Member("일지매", "il@tjoeun.com"));
//		memberRepository.save(new Member("홍길동", "gildong@tjoeun.com"));
//		memberRepository.save(new Member("홍길동", "hong@tjoeun.com"));
		
//		memberRepository.save(new Member(1L, "손오공", "hong@tjoeun.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(2L, "임꺽정", "lim@tjoeun.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(3L, "장길산", "jang@tjoeun.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(4L, "일지매", "il@tjoeun.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(5L, "홍길동", "gildong@tjoeun.com", LocalDateTime.now(), LocalDateTime.now()));
//		memberRepository.save(new Member(6L, "홍길동", "hong@tjoeun.com", LocalDateTime.now(), LocalDateTime.now()));
		
//		1줄 출력
		log.info("member 테이블에 저장된 데이터: " + memberRepository.findAll().toString());
//		여러줄 출력
		for (Member member : memberRepository.findAll()) {
			System.out.println(member);
		}
//		람다 식을 사용한 여러줄 출력
		memberRepository.findAll().forEach(System.out::println);
	}

//	JpaRepository 인터페이스가 제공하는 JPA 메소드 테스트
	@Test
	@Transactional // jakarta.transaction.Transactional
	void crud() {
		System.out.println("MemberRepositoryTest 클래스의 crud() 메소드 실행");
		
//		전체 데이터 가져오기: findAll()
		System.out.println("전체 데이터 가져오기 ========================================================");
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
//		전체 데이터를 정렬해서 가져오기: findAll(Sort 객체), org.springframework.data.domain
//		org.springframework.data.domain.Sort;
//		org.springframework.data.domain.Sort.Direction;
//		Sort.by(Direction.정렬방식, "정렬할 데이터가 저장된 필드 이름")
		System.out.println("전체 데이터를 정렬해서 가져오기 =============================================");
		members = memberRepository.findAll(Sort.by(Direction.ASC, "name")); // 오름차순 정렬
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAll(Sort.by(Direction.DESC, "id"));  // 내림차순 정렬
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
//		특정 id의 데이터 가져오기: findById().orElse(null)
		System.out.println("특정 id의 데이터 가져오기 ===================================================");
		Member member = memberRepository.getOne(1L);
		System.out.println(member);
		member = memberRepository.getById(2L);
		System.out.println(member);
		Optional<Member> member2 = memberRepository.findById(3L);
		System.out.println(member2);
		member = memberRepository.findById(4L).orElse(null); // 이거 추천
		System.out.println(member);
		System.out.println("=============================================================================");
		
//		여러 id의 데이터 가져오기: findAllById()
		System.out.println("여러 id의 데이터 가져오기 ===================================================");
		List<Long> ids = new ArrayList<>();
		ids.add(1L);
		ids.add(3L);
		ids.add(5L);
		members = memberRepository.findAllById(ids);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
//		org.assertj.core.util.Lists
		members = memberRepository.findAllById(Lists.newArrayList(2L, 4L, 6L));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
//		단일 데이터 저장하기: save()
//		save() 메소드는 존재하지 않는 id가 입력될 경우 insert sql 명령이 실행되고 존재하는 id가 입력될 경우
//		update sql 명령이 실행된다.
		System.out.println("단일 데이터 저장하기 ========================================================");
		memberRepository.save(new Member("손오공", "son@tjoeun.com")); // insert
		memberRepository.flush(); // 즉시 적용, 현재는 동작 확인이 안된다.
		memberRepository.saveAndFlush(new Member("저팔계", "jeo@tjoeun.com")); // 즉시 적용, insert
		memberRepository.save(new Member(1L, "김일승", "kim@tjoeun.com", LocalDateTime.now(), LocalDateTime.now())); // update
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
//		일괄 데이터 저장하기: saveAll()
		System.out.println("일괄 데이터 저장하기 ========================================================");
		Member member3 = new Member("사오정", "sa@tjoeun.com");
		Member member4 = new Member("삼장법사", "sam@tjoeun.com");
		memberRepository.saveAll(Lists.newArrayList(member3, member4));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
//		테이블에 저장된 데이터 개수 얻어오기: count()
		System.out.println("테이블에 저장된 데이터 개수 얻어오기 ========================================");
		long count = memberRepository.count();
		System.out.println(count);
		System.out.println("=============================================================================");
		
//		특정 아이디에 해당되는 데이터의 존재여부 얻어오기:
		System.out.println("테이블에 저장된 데이터 개수 얻어오기 ========================================");
		boolean exists = memberRepository.existsById(1L);
		System.out.println(exists);
		System.out.println(exists ? "있음" : "없음");
		exists = memberRepository.existsById(100L);
		System.out.println(exists);
		System.out.println("=============================================================================");
		
//		페이징: Page 인터페이스, org.springframework.data.domain.Page
		System.out.println("페이징 ======================================================================");
//		Page<페이징할 데이터가 저장된 테이블 이름> pages = memberRepository.findAll(PageRequest 객체)
//		org.springframework.data.domain.PageRequest
//		PageRequest.of(얻어올 페이지 번호, 페이지 크기[, 정렬 방식])
		Page<Member> pages = memberRepository.findAll(PageRequest.of(3, 3));
		System.out.println(pages); // 페이지 객체 출력
		pages.getContent().forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
	
//	JpaRepository 인터페이스가 제공하지 않기 때문에 사용자가 만든 JPA 메소드 테스트
	
}










