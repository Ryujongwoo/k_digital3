package com.tjoeun.springBootJPA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tjoeun.springBootJPA.domain.Member;

//	Repository는 @Entity 어노테이션을 붙여서 JPA가 자동으로 만든 테이블에서 실행할 JPA 메소드를 정의한다.
//	Repository로 사용할 모든 인터페이스는 JpaRepository 인터페이스를 상속받아서 만든다.
//	JpaRepository<@Entity 어노테이션을 붙여서 만든 클래스 이름, 기본키로 사용할 필드의 자료형>
//	JpaRepository 인터페이스가 제공하는 메소드를 살펴보려면 인터페이스 이름을 ctrl 키를 누른 상태로
//	클릭하면 JpaRepository 인터페이스가 새 창으로 열리고 메소드 목록이 표시된다.
public interface MemberRepository extends JpaRepository<Member, Long> {

//	JpaRepository 인터페이스에서 제공하지 않는 JPA 메소드를 정의한다.
	
	
}
