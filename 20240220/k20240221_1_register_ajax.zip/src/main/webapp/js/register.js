//	비밀번호가 일치하는가 확인하는 함수
function passwordCheckFunction() {
	let userPassword = $('#userPassword').val();
	let userPassword2 = $('#userPassword2').val();
	// console.log(`userPassword: ${userPassword}, userPassword2: ${userPassword2}`)
	
	if (userPassword != userPassword2) {
		$('#passwordCheckMessage').html('비밀번호가 일치하지 않습니다.')
	} else {
		$('#passwordCheckMessage').html('비밀번호가 일치 합니다.')
	}
}

//	===============================================================================================
//	jQuery AJAX
//	===============================================================================================

//	회원 가입을 실행하는 함수
function userRegister() {
//	index.jsp에서 테이블에 저장할 데이터를 얻어온다.
	let userID = $('#userID').val()
	let userPassword = $('#userPassword').val()
	let userPassword2 = $('#userPassword2').val()
	let userName = $('#userName').val()
	let userAge = $('#userAge').val()
	let userGender = $('input[name=userGender]:checked').val()
	let userEmail = $('#userEmail').val()
//	console.log(userID, userPassword, userPassword2, userName, userAge, userGender, userEmail)

//	jQuery AJAX
	$.ajax({
		type: 'GET', // 요청 방식
		url: './UserRegister?userID=' + userID + '&userPassword=' + userPassword + '&userName=' + userName +
			'&userAge=' + userAge + '&userGender=' + userGender + '&userEmail=' + userEmail // 요청할 서블릿
	})
}























