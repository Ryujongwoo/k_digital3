function fetchAJAX(pagename) {
	fetch(pagename)
		.then(response => {
			if (response.status == 200) {
				response.text().then(text => document.querySelectorAll('div')[0].innerHTML = text)
			} else {
				alert('요청 실패!!!')
			}
		})
}

$(() => {
	if (location.hash) {
		fetchAJAX(location.hash.substring(2))
	} else {
		fetchAJAX('summary')
	}
	
//	list 파일의 내용을 읽어서 <ol id="list"> ~ </ol> 사이에 넣어주는 fetch
	/*
	fetch('list')
		.then(response => {
			if (response.status == 200) {
				response.text().then(text => $('#list').html(text))
			} else {
				alert('요청 실패!!!')
			}
		})
	*/
	
//	then() 함수 내부에 then()이 또 나오는 기법을 nested라 한다.
//	fetch('list').then(response => response.text().then(text => $('#list').html(text)))
	
//	then()이 리턴한 결과를 외부에서 다른 then()이 받아서 처리하는 기법을 chaining이라 한다.
	fetch('list')
		.then(response => response.text())
		.then(text => $('#list').html(text))
	
})















