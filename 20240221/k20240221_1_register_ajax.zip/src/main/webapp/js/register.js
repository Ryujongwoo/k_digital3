//	비밀번호가 일치하는가 확인하는 함수
function passwordCheckFunction() {
	let userPassword = $('#userPassword').val();
	let userPassword2 = $('#userPassword2').val();
	// console.log(`userPassword: ${userPassword}, userPassword2: ${userPassword2}`)
	
	if (userPassword != userPassword2) {
		$('#passwordCheckMessage').html('비밀번호가 일치하지 않습니다.')
	} else {
		$('#passwordCheckMessage').html('비밀번호가 일치 합니다.')
	}
}

//	===============================================================================================
//	jQuery AJAX
//	===============================================================================================

//	회원 가입을 실행하는 함수
function userRegister() {
//	index.jsp에서 테이블에 저장할 데이터를 얻어온다.
	let userID = $('#userID').val()
	let userPassword = $('#userPassword').val()
	let userPassword2 = $('#userPassword2').val()
	let userName = $('#userName').val()
	let userAge = $('#userAge').val()
	let userGender = $('input[name=userGender]:checked').val()
	let userEmail = $('#userEmail').val()
//	console.log(userID, userPassword, userPassword2, userName, userAge, userGender, userEmail)

//	jQuery AJAX => $.ajax({ ... })
//	type에 GET 방식 요청은 GET, POST 방식 요청은 POST를 입력한다.
//	url에 요청할 서블릿을 입력한다.
//	서블릿으로 데이터를 전송하는 방법은 2가지가 있는데 url에 ?를 이용한 쿼리 스트링 방식을 사용하는 방법과
//	data에 { key: value, ...} 형태를 사용하는 방법이 있다.
//	success에 AJAX 요청이 성공하면 실행할 콜백 함수를 입력한다.
//	error에 AJAX 요청이 실패하면 실행할 콜백 함수를 입력한다.

	$.ajax({
//		type: 'GET', // GET 방식으로 서블릿을 요청한다.
		type: 'POST', // POST 방식으로 서블릿을 요청한다.
		
//		쿼리 스트링 사용한 서블릿 호출과 데이터 전송
//		url: './UserRegister?userID=' + userID + '&userPassword=' + userPassword + '&userPassword2=' + userPassword2 + 
//			'&userName=' + userName + '&userAge=' + userAge + '&userGender=' + userGender + '&userEmail=' + userEmail

//		data를 사용한 서블릿 호출과 데이터 전송
		url: './UserRegister',
		data: {
			// key: value
			userID: userID,
			userPassword: userPassword,
			userPassword2: userPassword2,
			userName: userName,
			userAge: userAge,
			userGender: userGender,
			userEmail: userEmail
		},
//		AJAX 요청이 성공하면 실행할 콜백 함수
//		AJAX 요청이 성공하면 response.getWriter().write(문자열)의 문자열이 콜백 함수의 인수로 넘어온다.
		success: res => {
			// alert('요청 성공: ' + res)
			// 다음 데이터를 입력받기 위해 텍스트 상자의 내용을 지운다.
			$('#userID').val('')
			$('#userPassword').val('')
			$('#userPassword2').val('')
			$('#userName').val('')
			$('#userAge').val('')
			$('#userGender').val('')
			$('#userEmail').val('')
			$('#userID').focus()
			
			// 서블릿 응답에 따른 메시지를 출력한다.
			switch (res) {
				case '1':
					// alert('에러: 모든 내용을 입력하세요.')
					$('#errorMessage').html('에러: 모든 내용을 입력하세요.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('모든 내용을 입력하세요.')
					// $('#messageCheck').attr('class', 'modal-header bg-warning')
					$('#messageCheck').addClass('bg-danger')
					break
				case '2':
					// alert('에러: 비밀번호가 일치하지 않습니다.')
					$('#errorMessage').html('에러: 비밀번호가 일치하지 않습니다.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('비밀번호가 일치하지 않습니다.')
					// $('#messageCheck').attr('class', 'modal-header bg-warning')
					$('#messageCheck').addClass('bg-dark text-white')
					break
				case '3':
					// alert('회원 가입에 성공했습니다.')
					$('#errorMessage').html('회원 가입에 성공했습니다.')
					$('#messageType').html('성공 메시지')
					$('#messageContent').html('회원 가입에 성공했습니다.')
					// $('#messageCheck').attr('class', 'modal-header bg-success')
					$('#messageCheck').addClass('bg-primary')
					break
				case '4':
					// alert('에러: 이미 존재하는 회원 ID 입니다.')
					$('#errorMessage').html('에러: 이미 존재하는 회원 ID 입니다.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('이미 존재하는 회원 ID 입니다.')
					// $('#messageCheck').attr('class', 'modal-header bg-warning')
					$('#messageCheck').addClass('bg-info')
					break
			}
			// 모달 창을 띄운다.
			$('#messageModal').modal('show')
		},
//		AJAX 요청이 실패하면 실행할 콜백 함수
//		AJAX 요청이 실패하면 에러 정보가 콜백 함수의 인수로 넘어온다.
		error: e => alert('요청 실패: ' + e.status)
		
	})
}

//	아이디 중복 검사를 실행하는 함수
function registerCheckFunction() {
//	중복 검사할 ID를 얻어온다.
	let userID = $('#userID').val()
//	console.log(userID)

	$.ajax({
		type: 'POST',
		url: './UserRegisterCheck',
		data: {
			userID: userID
		},
		success: res => {
			// alert('요청 성공: ' + res)
			switch (res) {
				case "1":
					// alert('ID를 입력하고 중복 체크 버튼을 클릭하세요.')
					$('#idCheckMessage').html('ID를 입력하고 중복 체크 버튼을 클릭하세요.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('ID를 입력하고 중복 체크 버튼을 클릭하세요.')
					$('#messageCheck').addClass('bg-danger')
					$('#userID').val('')
					$('#userID').focus()
					break;
				case "2":
					// alert('이미 사용중인 ID 입니다.')
					$('#idCheckMessage').html('이미 사용중인 ID 입니다.')
					$('#messageType').html('에러 메시지')
					$('#messageContent').html('이미 사용중인 ID 입니다.')
					$('#messageCheck').addClass('bg-warning')
					$('#userID').val('')
					$('#userID').focus()
					break;
				case "3":
					// alert('사용 가능한 ID 입니다.')
					$('#idCheckMessage').html('사용 가능한 ID 입니다.')
					$('#messageType').html('성공 메시지')
					$('#messageContent').html('사용 가능한 ID 입니다.')
					$('#messageCheck').addClass('bg-success')
					$('#userPassword').focus()
					break;
			}
			$('#messageModal').modal('show')
		},
		error: e => alert('요청 실패: ' + e.status)
	})
}





























