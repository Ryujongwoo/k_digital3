const myName = document.getElementById('my-name');
console.log(myName); // null
console.log(myName.innerText); // 에러
