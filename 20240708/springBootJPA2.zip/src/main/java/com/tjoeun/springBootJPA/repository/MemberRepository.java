package com.tjoeun.springBootJPA.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.tjoeun.springBootJPA.domain.Member;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.data.util.Streamable;

public interface MemberRepository extends JpaRepository<Member, Long> {

	public List<Member> findByName(String name);
	public List<Member> findByEmail(String email);
	public List<Member> getByEmail(String email);
	public List<Member> queryByEmail(String email);
	public List<Member> readByEmail(String email);
	public List<Member> searchByEmail(String email);
	public List<Member> streamByEmail(String email);
	
	public List<Member> findFirst2ByName(String name);
	public List<Member> findTop2ByName(String name);
	public List<Member> findLast2ByName(String name);
	
	public List<Member> findByCreateAtAfter(LocalDateTime date);
	public List<Member> findByCreateAtBefore(LocalDateTime date);
	public List<Member> findByIdGreaterThan(Long id);
	public List<Member> findByIdLessThan(Long id);
	public List<Member> findByIdGreaterThanEqual(Long id);
	public List<Member> findByIdLessThanEqual(Long id);
	
	public List<Member> findByNameAndEmail(String name, String email);
	public List<Member> findByEmailAndName(String email, String name);
	public List<Member> findByNameOrEmail(String name, String email);
	public List<Member> findByEmailOrName(String email, String name);
	public List<Member> findByIdGreaterThanEqualAndIdLessThanEqual(Long id1, Long id2);
	public List<Member> findByIdBetween(Long id1, Long id2);

	public List<Member> findByUpdateAtIsNull();
	public List<Member> findByUpdateAtIsNotNull();
	public List<Member> findByNameIn(List<String> names);
	public List<Member> findByNameNotIn(List<String> names);
	
	public List<Member> findByNameLike(String name);
	public List<Member> findByNameStartingWith(String name);
	public List<Member> findByNameEndingWith(String name);
	public List<Member> findByNameContains(String name);
	
	public List<Member> findAllByOrderByEmailAsc();
	public List<Member> findAllByOrderByNameDesc();
	public List<Member> findByNameOrderByEmailAsc(String name);
	public List<Member> findByNameOrderByIdDesc(String name);
	
	public List<Member> findTop2AllByOrderByEmailAsc();
	public List<Member> findFirst2AllByOrderByNameDesc();
	public List<Member> findTop1ByNameOrderByEmailAsc(String name);
	public List<Member> findFirst1ByNameOrderByIdDesc(String name);
	public List<Member> findTopByNameOrderByEmailAsc(String name);
	public List<Member> findFirstByNameOrderByIdDesc(String name);
	
	public List<Member> findAllByOrderByEmailAscIdDesc();
	public List<Member> findAllByOrderByNameDescEmailAscIdDesc();
	public List<Member> findByNameOrderByEmailAscIdDesc(String name);
	public List<Member> findAll(Sort sort);
	public List<Member> findByName(String name, Sort sort);
	
	public Page<Member> findAll(Pageable pageable);
	public Page<Member> findByName(String name, Pageable pageable);
	
//	네이티브 쿼리
	@Query(value = "select * from member2 limit 1;", nativeQuery = true)
	public Map<String, Object> findRawRecoed();
	
}










