package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.PostRemove;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Data
@Builder
@Slf4j

@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)

//	@Table 어노테이션으로 테이블 이름 변경, 인덱스 생성, 유일성 제약 사항을 지정할 수 있다.
//	name 속성으로 @Entity 어노테이션을 붙여서 선언한 클래스 이름과 다르게 테이블 이름을 지정할 수 있다.
//	indexes 속성으로 @Index 어노테이션을 이용해서 인덱스를 만들 수 있다.
//	uniqueConstraints 속성으로 @UniqueConstraint 어노테이션을 이용해서 유일성 제약 사항을 지정할 수 있다.
@Table(
	name = "member2", // 변경할 테이블 이름
	indexes = {@Index(columnList = "name")}, // 인덱스 생성
	uniqueConstraints = {@UniqueConstraint(columnNames = "email")} // 유일성 제약 사항
)
public class Member {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	@NonNull
	private String name;
	@NonNull
	private String email;

	@NonNull
//	@Column 어노테이션은 테이블의 별도의 필드 설정이 필요한 경우 붙인다.
//	@Column 어노테이션은 필드 이름 변경, null 값 허용 여부, 유일성 제약 사항 설정, 필드 크기 지정, 
//	insert, update sql 명령 실행시 필드 포함 여부 지정 작업들을 할 수 있다.
//	name 속성으로 필드 이름과 다른 이름으로 테이블의 필드 이름을 지정할 수 있다.
//	nullable 속성값을 false로 지정해서 null 값을 허용하지 않는 필드를 만들 수 있다.
//	unique 속성값을 true로 지정해서 중복되는 값을 허용하지 않는 필드를 만들 수 있다.
//	length 속성으로 필드의 크기를 지정할 수 있다.
	@Column(
		name = "nick", // 필드 이름 변경
		nullable = false, // null 값을 허용하지 않는 필드
		unique = true, // 중복되는 값을 허용하지 않는 필드
		length = 100 // 필드 크기 지정
	)
	private String nickname;
	
//	@Column 어노테이션의 updatable 속성값을 false로 지정하면 update sql 명령 실행시 필드를 반영하지 않는다.
	@Column(updatable = false)
	private LocalDateTime createAt;
//	@Column 어노테이션의 insertable 속성값을 false로 지정하면 insert sql 명령 실행시 필드를 반영하지 않는다.
	@Column(insertable = false)
	private LocalDateTime updateAt;
	
//	@Transient 어노테이션은 프로그래밍 작업에는 필요한데 데이터베이스 테이블에는 반영하지 않을 필드에
//	붙여준다.
	@Transient
	private String testData;
	
//	@Enumerated 어노테이션은 enum 객체를 사용할 때 인덱스 사용 방식을 지정한다.
//	value 속성의 기본값은 EnumType.ORDINAL 이고 enum 파일의 순서가 변경되면 인덱스가 같이 변경되는
//	문제점이 발생될 수 있다.
//	@Enumerated(value = EnumType.ORDINAL)
//	이를 방지하기 위해 @Enumerated 어노테이션의 value 속성의 값을 EnumType.STRING로 변경하면 인덱스가
//	아닌 문자열로 처리되므로 인덱스가 변경되는 문제가 발생되지 않는다.
	@Enumerated(value = EnumType.STRING)
	private Gender gender;
	
//	JPA가 제공하는 엔티티 이벤트는 모두 7가지가 있다.
	
//	@PrePersist 어노테이션을 붙여 선언한 메소드는 insert sql 명령이 실행되기 전에 실행된다.
	@PrePersist
	public void prePersist() { // 메소드 이름은 뭐로 만들어도 상관없다.
		System.out.println("===== insert sql 명령 실행 전에 prePersist() 메소드 실행 =====");
		createAt = LocalDateTime.now();
		updateAt = LocalDateTime.now();
	}
	
//	@PostPersist 어노테이션을 붙여 선언한 메소드는 insert sql 명령이 실행된 후에 실행된다.
	@PostPersist
	public void postPersist() {
		System.out.println("===== insert sql 명령 실행 후에 postPersist() 메소드 실행 =====");
	}
	
//	@PostLoad 어노테이션을 붙여 선언한 메소드는 select sql 명령이 실행된 후에 실행된다.
	@PostLoad
	public void postLoad() {
		System.out.println("===== select sql 명령 실행 후에 postLoad() 메소드 실행 =====");
	}
	
//	@PreUpdate 어노테이션을 붙여 선언한 메소드는 update sql 명령이 실행되기 전에 실행된다.
	@PreUpdate
	public void preUpdate() {
		System.out.println("===== update sql 명령 실행 전에 preUpdate() 메소드 실행 =====");
	}
	
//	@PostUpdate 어노테이션을 붙여 선언한 메소드는 update sql 명령이 실행된 후에 실행된다.
	@PostUpdate
	public void postUpdate() {
		System.out.println("===== update sql 명령 실행 후에 postUpdate() 메소드 실행 =====");
	}
	
//	@PreRemove 어노테이션을 붙여 선언한 메소드는 delete sql 명령이 실행되기 전에 실행된다.
	@PreRemove
	public void preRemove() {
		System.out.println("===== delete sql 명령 실행 전에 preRemove() 메소드 실행 =====");
	}
	
//	@PostRemove 어노테이션을 붙여 선언한 메소드는 delete sql 명령이 실행된 후에 실행된다.
	@PostRemove
	public void postRemove() {
		System.out.println("===== delete sql 명령 실행 후에 postRemove() 메소드 실행 =====");
	}
	
}












