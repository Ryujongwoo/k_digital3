package com.tjoeun.springBootBoard.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tjoeun.springBootBoard.dto.CommentDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Slf4j
public class Comment { // 댓글 테이블

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne // 댓글 엔티티 여러개가 메인글 1개와 연관된다.
//	별도의 설정이 없으면 외래키 필드의 이름은 참조하는 테이블 이름과 참조하는 테이블의 기본키 필드의
//	이름을 "_"로 연결해서 만들어준다. => article_id
//	외래키 필드 이름을 직접 지정하려면 @JoinColumn 어노테이션의 name 속성에 별도로 지정할 외래키의
//	이름을 지정하면 된다.
	@JoinColumn(name = "article_id")
//	comment 테이블에는 article_id 필드가 추가되고 article 테이블의 기본키 필드 값이 저장된다.
	private Article article;
	
	@Column
	private String nickname;
	@Column
	private String body;
	
//	CommentDto 객체를 Comment 엔티티 객체로 변환하는 메소드
	public static Comment createComment(Article article, CommentDto commentDto) {
		log.info("Comment 클래스의 createComment() 메소드 실행");
		log.info("article = {}", article);
		log.info("commentDto = {}", commentDto);
		
//		댓글의 id는 JPA가 자동으로 붙여주기 때문에 id가 넘어오는 경우 예외를 발생시킨다.
		if (commentDto.getId() != null) {
			throw new IllegalArgumentException("댓글 저장 실패!!! 댓글의 id가 없어야 합니다.");
		}
//		테이블에 저장된 메인글의 id와 댓글을 작성하기 위해 요청한 메인글의 id 다르면 예외를 발생시킨다.
		if (article.getId() != commentDto.getArticleId()) {
			throw new IllegalArgumentException("댓글 저장 실패!!! 메인글의 id가 올바르지 않습니다.");
		}
		return new Comment(
			commentDto.getId(), article, commentDto.getNickname(), commentDto.getBody()
		);
	}

//	댓글을 수정하는 메소드
	public void patch(CommentDto commentDto) {
		log.info("Comment 클래스의 patch() 메소드 실행");
		log.info("commentDto = {}", commentDto);

//		수정하려는 댓글의 id와 테이블에 저장된 id가 다르면 예외를 발생시킨다.
		if (this.id != commentDto.getId()) {
			throw new IllegalArgumentException("댓글 수정 실패!!! 수정할 댓글의 id가 올바르지 않습니다.");
		}
//		댓글을 수정한다.
		if (commentDto.getNickname() != null) {
			this.nickname = commentDto.getNickname();
		}
		if (commentDto.getBody() != null) {
			this.body = commentDto.getBody();
		}
	}
	
	
}






