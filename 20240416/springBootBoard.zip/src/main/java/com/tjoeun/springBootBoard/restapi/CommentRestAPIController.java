package com.tjoeun.springBootBoard.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tjoeun.springBootBoard.dto.CommentDto;
import com.tjoeun.springBootBoard.entity.Comment;
import com.tjoeun.springBootBoard.service.CommentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CommentRestAPIController {

//	CommentService 클래스의 멤소드를 사용하기 위해 CommentService 클래스의 bean을 얻어온다.
	@Autowired
	private CommentService commentService;
	
//	메인글의 id에 따른 댓글 목록 조회
//	Talend API Tester(GET) => http://localhost:9090/restapi/comments/1
	@GetMapping("/restapi/comments/{articleId}")
	public ResponseEntity<List<CommentDto>> comments(@PathVariable Long articleId) {
		log.info("CommentRestAPIController의 comments() 메소드 실행");
		log.info("articleId = {}", articleId);
//		서비스에 위임
		List<CommentDto> comments = commentService.comments(articleId);
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(comments);
	}
	
//	댓글 입력
//	Talend API Tester(POST) => http://localhost:9090/restapi/comments/1
//	articleId와 commentDto의 id가 다를 경우 예외를 발생시킨다.
//	articleId가 존재하지 않는 메인글의 id일 경우 예외를 발생시킨다.
//	Talend API 테스트 body 데이터
//	{	
//	  "articleId": 3,
//	  "nickname": "일지매",
//	  "body": "없음"
//	}
//	자바스크립트는 예전 부터 스네이크 표기법을 사용해왔고 자바는 카멜 표기법을 주로 사용하기 때문에
//	body 데이터를 articleId와 같이 카멜 표기법으로 작성하면 문제없이 처리되지만 article_id와 같이
//	스네이크 표기법으로 작성하면 자바 클래스에서 articleId와 같이 작성하기 때문에 변수 이름이 달라져서
//	데이터를 넘겨받지 못한다.
//	자바스크립트에서 스네이크 표기법으로 작성된 데이터를 카멜 표기법으로 작성된 자바 클래서 변수에
//	정상적으로 저장되게 하기 위해서 @JsonProperty("자바스크립트에서 스네이크 표기법으로 작성된 변수")
//	어노테이션을 지정해서 받을 수 있다.
	@PostMapping("/restapi/comments/{articleId}")
	public ResponseEntity<CommentDto> create(
		@PathVariable Long articleId, @RequestBody CommentDto commentDto) {
		log.info("CommentRestAPIController의 create() 메소드 실행");
		log.info("articleId = {}, commentDto = {}", articleId, commentDto);
//		서비스에 위임
		CommentDto createDto = commentService.create(articleId, commentDto);
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(createDto);
	}
	
//	댓글 수정
//	Talend API Tester(PATCH) => http://localhost:9090/restapi/comments/1
//	Talend API 테스트 body 데이터
//	{	
//	  "id": 1
//	  "articleId": 1,
//	  "nickname": "일지매",
//	  "body": "없음"
//	}
	@PatchMapping("/restapi/comments/{id}")
	public ResponseEntity<CommentDto> update(
		@PathVariable Long id, @RequestBody CommentDto commentDto) {
		log.info("CommentRestAPIController의 update() 메소드 실행");
		log.info("id = {}, commentDto = {}", id, commentDto);
//		서비스에 위임
		CommentDto createDto = commentService.update(id, commentDto);
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(createDto);
	}
	
//	댓글 삭제
//	Talend API Tester(DELETE) => http://localhost:9090/restapi/comments/1	
	@DeleteMapping("/restapi/comments/{id}")
	public ResponseEntity<CommentDto> delete(@PathVariable Long id) {
		log.info("CommentRestAPIController의 delete() 메소드 실행");
		log.info("id = {}", id);
//		서비스에 위임
		CommentDto deleteDto = commentService.delete(id);
//		결과 응답
		return ResponseEntity.status(HttpStatus.OK).body(deleteDto);
	}
			
}











