package com.tjoeun.onLinePoll;

import java.util.ArrayList;

public class PollRead {

//	텍스트 파일의 이름을 넘겨받고 내용을 읽어서 ArrayList에 저장해서 리턴하는 메소드
	public static ArrayList<String> pollRead(String filepath) {
		
		
		System.out.println("pollRead() 메소드 실행");
		
		
		return null;
		
	}
	
}
