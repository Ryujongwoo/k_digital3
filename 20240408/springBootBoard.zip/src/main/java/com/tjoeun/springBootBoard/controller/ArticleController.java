package com.tjoeun.springBootBoard.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j // 롬복에서 지원하는 로그 어노테이션
public class ArticleController {

//	JPA Repository 인터페이스 객체를 선언하고 @Autowired 어노테이션을 붙여 초기화 시킨다.
	@Autowired // springBoot가 미리 생성해놓은 bean(객체)를 가져다 자동으로 초기화 시킨다.
	private ArticleRepository articleRepository;
	
	@GetMapping("/articles/new")
	public String newArticleForm() {
		System.out.println("ArticleController의 newArticleForm() 메소드 실행");
//		@Slf4j 어노테이션 로그 레벨, 로그는 반드시 문자열로 지정한다.
//		log.trace(): 가장 디테일한 로그
//		log.warn(): 경고 로그
//		log.info(): 정보성 로그
//		log.debug(): 디버깅용 로그
//		log.error(): 에러 로그
		log.info("ArticleController의 newArticleForm() 메소드 실행");
		return "articles/new";
	}
	
	@PostMapping("/articles/create")
//	form에서 넘어오는 데이터는 DTO 커맨드 객체로 받으면 편리하다.
	public String createArticle(HttpServletRequest request, ArticleForm articleForm, Model model) {
		System.out.println("ArticleController의 createArticle() 메소드 실행");
//		System.out.println(request.getParameter("title"));
//		System.out.println(request.getParameter("content"));
		System.out.println(articleForm);
		
//		DTO의 데이터를 엔티티로 변환한다.
		Article article = articleForm.toEntity();
		System.out.println(article);
		
//		Repository에서 엔티티를 데이터베이스에 저장하는 save() 메소드를 실행한다.
//		insert sql 명령이 실행된다. id가 자동으로 생성된다.
//		save() 메소드를 실행하면 데이터베이스에 저장된 엔티티 객체가 리턴된다.
		Article saved = articleRepository.save(article);
		System.out.println(saved);
		
		return "/articles/new";
	}
	
}
