package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

//	@PrePersist, @PreUpdate 어노테이션을 붙여서 선언한 엔티티 이벤트 메소드로 실행하던 필드 초기화를
//	엔티티 이벤터 리스너로 하기 위해 엔티티 이벤트 메소드로 초기화 하던 필드를 선언하지 않고 setter 
//	메소드를 추상 메소드로 가지는 인터페이스를 선언한다. getter 메소드는 구현하지 않아도 상관없다.
//	이렇게 선언한 인터페이스는 엔티티 이벤트 리스너를 사용할 엔티티 클래스 구현해서 사용한다.
public interface Auditable {

//	LocalDateTime getCreateAt();
//	LocalDateTime getUpdateAt();
	void setCreateAt(LocalDateTime createAt);
	void setUpdateAt(LocalDateTime updateAt);
	
}
