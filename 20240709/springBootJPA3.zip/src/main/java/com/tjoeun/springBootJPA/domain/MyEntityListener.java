package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

//	엔티티 이벤트 리스너를 만든다.
public class MyEntityListener {

//	엔티티 이벤트 리스너는 여러 엔티티에서 사용될 수 있으므로 @PrePersist, @PreUpdate 어노테이션을 
//	붙여서 엔티티 이벤트를 처리하는 메소드를 만든다.
//	엔티티 이벤트 리스너에는 엔티티 이벤트 리스너를 구현하기 위해 선언해서 엔티티 클래스에 구현한
//	인터페이스(Auditable)가 구현된 엔티티 객체가 자동으로 넘어온다.
//	엔티티 이벤트 리스너가 실행될 때 마다 엔티티 이벤트 리스너로 넘어오는 엔티티 객체가 달라질 수
//	있기 때문에 모든 객체를 받아서 처리할 수 있도록 Object 클래스 타입의 인수를 지정해 사용한다.
	
	@PrePersist
	public void prePersist(Object object) {
		System.out.println("MyEntityListener 클래스의 prePersist() 메소드 실행");
//		엔티티 이벤트 리스너를 구현하는 클래스에는 필드를 별도로 만들어 사용하지 않기 때문에 아래와
//		같이 엔티티 이벤트에서 사용던 코드는 사용할 수 없다.
//		createAt = LocalDateTime.now();
//		updateAt = LocalDateTime.now();
//		prePersist() 메소드의 인수로 넘어온 객체가 Auditable 인터페이스로 정상적으로 형변환이 된다면
//		엔티티 이벤트 리스너를 사용하는 엔티티 객체이므로 작성일과 수정일을 저장한다.
		if (object instanceof Auditable) {
			((Auditable) object).setCreateAt(LocalDateTime.now());
			((Auditable) object).setUpdateAt(LocalDateTime.now());
		}
	}
	
	@PreUpdate
	public void preUpdate(Object object) {
		System.out.println("MyEntityListener 클래스의 preUpdate() 메소드 실행");
//		preUpdate() 메소드의 인수로 넘어온 객체가 Auditable 인터페이스로 정상적으로 형변환이 된다면
//		엔티티 이벤트 리스너를 사용하는 엔티티 객체이므로 수정일을 저장한다.
		if (object instanceof Auditable) {
			((Auditable) object).setUpdateAt(LocalDateTime.now());
		}
	}
	
}
