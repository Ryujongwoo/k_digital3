package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
//	@EntityListeners 어노테이션으로 엔티티 이벤트 리스너를 지정한다.
@EntityListeners(value = MyEntityListener.class)
//	엔티티 이벤트 리스너를 적용할 엔티티 클래스에 Auditable 인터페이스를 구현한다.
//	Auditable 인터페이스의 추상 메소드 Override는 롬복이 자동으로 처리한다.
public class Book implements Auditable {

	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	private String author;
	private LocalDateTime createAt;
	private LocalDateTime updateAt;
	
//	대부분의 엔티티는 작성일과 수정일을 저장하는 메소드가 필요할 것이다.
//	매번 엔티티를 생성할 때 마다 @PrePersist, @PreUpdate 어노테이션을 붙여서 엔티티 이벤트를 만들어
//	사용해도 되지만 같은 작업이 반복되므로 코드 리펙토링 차원에서 엔티티 리스너를 지정해서 사용하는
//	것을 권장한다.
	
//	엔티티 리스너를 지정해 사용할 것이므로 @PrePersist, @PreUpdate 어노테이션을 붙여서 구현한 엔티티
//	이벤트 메소드는 제거한다.
//	@PrePersist // 엔티티 이벤트
//	public void prePersist() {
//		createAt = LocalDateTime.now();
//		updateAt = LocalDateTime.now();
//	}
	
//	@PreUpdate // 엔티티 이벤트
//	public void preUpdate() {
//		updateAt = LocalDateTime.now();
//	}
	
}









