package com.tjoeun.springBootJPA.domain;

import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

public class MemberHistoryListener {

//	엔티티 이벤트 리스너(MemberHistoryListener) 클래스는 @Autowired에 의해서 자동으로 bean을
//	주입받지 못한다.
	@Autowired
	private MemberHistoryRepository memberHistoryRepository;
	
//	@PrePersist, @PreUpdate 어노테이션을 모두 사용해서 메소드를 만들면 insert, update sql 명령이
//	실행되기 전에 모두 메소드가 실행된다.
	@PrePersist
	@PreUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 클래스의 prePersistAndPreUpdate() 메소드 실행");
//		자동으로 bean을 주입받지 못하기 때문에 null이 출력된다.
		System.out.println(memberHistoryRepository);
	}
	
	
}
