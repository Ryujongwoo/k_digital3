package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.PostRemove;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Data
@Builder
@Slf4j

@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
@Table(name = "member2", indexes = {@Index(columnList = "name")}, uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
//	@EntityListeners(value = MyEntityListener.class)
//	엔티티 이벤트 리스너가 2개 이상 사용되면 {}로 묶어서 ","로 구분해서 나열한다.
@EntityListeners(value = {MyEntityListener.class, MemberHistoryListener.class})
public class Member implements Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	@NonNull
	private String name;
	@NonNull
	private String email;
	@NonNull
	@Column(name = "nick", nullable = false, unique = true, length = 100)
	private String nickname;
	@Column(updatable = false)
	private LocalDateTime createAt;
	@Column(insertable = false)
	private LocalDateTime updateAt;
	@Transient
	private String testData;
	@Enumerated(value = EnumType.STRING)
	private Gender gender;
	
//	@PrePersist
//	public void prePersist() {
//		System.out.println("===== insert sql 명령 실행 전에 prePersist() 메소드 실행 =====");
//		createAt = LocalDateTime.now();
//		updateAt = LocalDateTime.now();
//	}
	
//	@PostPersist
//	public void postPersist() {
//		System.out.println("===== insert sql 명령 실행 후에 postPersist() 메소드 실행 =====");
//	}
	
//	@PostLoad
//	public void postLoad() {
//		System.out.println("===== select sql 명령 실행 후에 postLoad() 메소드 실행 =====");
//	}
	
//	@PreUpdate
//	public void preUpdate() {
//		System.out.println("===== update sql 명령 실행 전에 preUpdate() 메소드 실행 =====");
//		updateAt = LocalDateTime.now();
//	}
	
//	@PostUpdate
//	public void postUpdate() {
//		System.out.println("===== update sql 명령 실행 후에 postUpdate() 메소드 실행 =====");
//	}
	
//	@PreRemove
//	public void preRemove() {
//		System.out.println("===== delete sql 명령 실행 전에 preRemove() 메소드 실행 =====");
//	}
	
//	@PostRemove
//	public void postRemove() {
//		System.out.println("===== delete sql 명령 실행 후에 postRemove() 메소드 실행 =====");
//	}
	
}












