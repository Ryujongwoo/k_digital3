package com.tjoeun.springBootJPA.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

import com.tjoeun.springBootJPA.domain.Gender;
import com.tjoeun.springBootJPA.domain.Member;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberRepositoryTest {

	@Autowired
	private MemberRepository memberRepository;
	
	@Test
	void test() {
		System.out.println("MemberRepositoryTest 클래스의 test() 메소드 실행");
		memberRepository.findAll().forEach(System.out::println);
	}

	@Test
	@Transactional
	void crud() {
		System.out.println("MemberRepositoryTest 클래스의 crud() 메소드 실행");
		
		System.out.println("전체 데이터 가져오기 ========================================================");
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("전체 데이터를 정렬해서 가져오기 =============================================");
		members = memberRepository.findAll(Sort.by(Direction.ASC, "name"));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAll(Sort.by(Direction.DESC, "id"));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("특정 id의 데이터 가져오기 ===================================================");
		Member member = memberRepository.getOne(1L);
		System.out.println(member);
		member = memberRepository.getById(2L);
		System.out.println(member);
		Optional<Member> member2 = memberRepository.findById(3L);
		System.out.println(member2);
		member = memberRepository.findById(4L).orElse(null);
		System.out.println(member);
		System.out.println("=============================================================================");
		
		System.out.println("여러 id의 데이터 가져오기 ===================================================");
		List<Long> ids = new ArrayList<>();
		ids.add(1L);
		ids.add(3L);
		ids.add(5L);
		members = memberRepository.findAllById(ids);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAllById(Lists.newArrayList(2L, 4L, 6L));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("단일 데이터 저장하기 ========================================================");
		memberRepository.save(new Member("손오공", "son@tjoeun.com", "원숭이"));
		memberRepository.flush();
		memberRepository.saveAndFlush(new Member("저팔계", "jeo@tjoeun.com", "돼지"));
		memberRepository.save(new Member(1L, "김일승", "kim@tjoeun.com", "별명", LocalDateTime.now(), LocalDateTime.now(), "DATA", Gender.FEMALE));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("일괄 데이터 저장하기 ========================================================");
		Member member3 = new Member("사오정", "sa@tjoeun.com", "나방");
		Member member4 = new Member("삼장법사", "sam@tjoeun.com", "스님");
		memberRepository.saveAll(Lists.newArrayList(member3, member4));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("테이블에 저장된 데이터 개수 얻어오기 ========================================");
		long count = memberRepository.count();
		System.out.println(count);
		System.out.println("=============================================================================");
		
		System.out.println("테이블에 저장된 데이터 개수 얻어오기 ========================================");
		boolean exists = memberRepository.existsById(1L);
		System.out.println(exists);
		System.out.println(exists ? "있음" : "없음");
		exists = memberRepository.existsById(100L);
		System.out.println(exists);
		System.out.println("=============================================================================");
		
		System.out.println("페이징 ======================================================================");
//		PageRequest.of(얻어올 페이지 번호, 페이지 크기[, 정렬 방식])
//		Page<Member> pages = memberRepository.findAll(PageRequest.of(3, 3));
//		Page<Member> pages = memberRepository.findAll(PageRequest.of(3, 3, Sort.by(Direction.ASC, "name")));
		Page<Member> pages = memberRepository.findAll(PageRequest.of(3, 3, Sort.by(Direction.DESC, "id")));
		System.out.println(pages);
		pages.getContent().forEach(System.out::println);
		System.out.println("전체 데이터의 개수 >> " + pages.getTotalElements());
		System.out.println("현재 페이지의 데이터의 개수 >> " + pages.getNumberOfElements());
		System.out.println("1페이지의 데이터의 개수 >> " + pages.getSize());
		System.out.println("정렬 여부 >> " + pages.getSort());
		System.out.println("=============================================================================");
		
		System.out.println("단일 데이터 삭제하기 ========================================================");
		memberRepository.delete(memberRepository.findById(1L).orElse(null));
		memberRepository.deleteById(2L);
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("특정 id의 데이터 삭제하기 ===================================================");
		memberRepository.deleteAll(memberRepository.findAllById(Lists.newArrayList(4L, 5L)));
		memberRepository.deleteInBatch(memberRepository.findAllById(Lists.newArrayList(7L, 8L)));
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("전체 데이터 삭제하기 ========================================================");
		memberRepository.deleteAll();
		members = memberRepository.findAll();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
	
	@Test
	@Transactional
	void select() {
		System.out.println("MemberRepositoryTest 클래스의 select() 메소드 실행");
		
		System.out.println("findByName() 메소드 실행하기 ================================================");
//		Member member = memberRepository.findByName("홍길동"); // 에러 발생
//		Member member = memberRepository.findByName("임꺽정"); // 정상 실행
//		System.out.println(member);
		List<Member> members = memberRepository.findByName("홍길동"); // 정상 실행
//		List<Member> members = memberRepository.findByName("임꺽정"); // 정상 실행
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("*Email() 메소드 실행하기 ====================================================");
		members = memberRepository.findByEmail("hong@tjoeun.com");
//		members = memberRepository.getByEmail("hong@tjoeun.com");
//		members = memberRepository.queryByEmail("hong@tjoeun.com");
//		members = memberRepository.readByEmail("hong@tjoeun.com");
//		members = memberRepository.searchByEmail("hong@tjoeun.com");
//		members = memberRepository.streamByEmail("hong@tjoeun.com");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("limit를 지정하는 메소드 실행하기 ============================================");
		members = memberRepository.findFirst2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findTop2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");

		System.out.println("지원되지 않는 메소드 실행하기 ===============================================");
		members = memberRepository.findLast2ByName("홍길동");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
	@Test
	@Transactional
	void select2() {
		System.out.println("MemberRepositoryTest 클래스의 select2() 메소드 실행");

		System.out.println("초과, 미만 조건을 사용하는 메소드 실행하기 ==================================");
		List<Member> members = memberRepository.findByCreateAtAfter(LocalDateTime.now().minusDays(1L));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByCreateAtBefore(LocalDateTime.now().plusDays(1L));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByIdGreaterThan(4L);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByIdLessThan(3L);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("이상, 이하 조건을 사용하는 메소드 실행하기 ==================================");
		members = memberRepository.findByIdGreaterThanEqual(4L);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByIdLessThanEqual(3L);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");

		System.out.println("And, Or 조건을 사용하는 메소드 실행하기 =====================================");
		members = memberRepository.findByNameAndEmail("홍길동", "hong@tjoeun.com");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByEmailAndName("hong@tjoeun.com", "홍길동");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameOrEmail("임꺽정", "gildong@tjoeun.com");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByEmailOrName("gildong@tjoeun.com", "임꺽정");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("Between을 사용하는 메소드 실행하기 ==========================================");
		members = memberRepository.findByIdGreaterThanEqualAndIdLessThanEqual(2L, 4L);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByIdBetween(2L, 4L);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
	@Test
	@Transactional
	void select3() {
		System.out.println("MemberRepositoryTest 클래스의 select3() 메소드 실행");

		System.out.println("IsNull, IsNotNull 조건을 사용하는 메소드 실행하기 ===========================");
		List<Member> members = memberRepository.findByUpdateAtIsNull();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByUpdateAtIsNotNull();
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("In, NotIn 조건을 사용하는 메소드 실행하기 ===================================");
		members = memberRepository.findByNameIn(Lists.newArrayList("홍길동", "장길산"));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameNotIn(Lists.newArrayList("홍길동", "장길산"));
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("Like 조건을 사용하는 메소드 실행하기 ========================================");
		members = memberRepository.findByNameLike("임%");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameLike("%매");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameLike("%길%");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameStartingWith("임");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameEndingWith("매");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameContains("길");
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
	@Test
	@Transactional
	void sort() {
		System.out.println("MemberRepositoryTest 클래스의 sort() 메소드 실행");

		System.out.println("전체 데이터를 정렬하는 메소드 실행하기 ======================================");
		List<Member> members = memberRepository.findAllByOrderByEmailAsc(); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAllByOrderByNameDesc(); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("특정 조건을 만족하는 데이터만 선택해서 정렬하는 메소드 실행하기 =============");
		members = memberRepository.findByNameOrderByEmailAsc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameOrderByIdDesc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("정렬 결과에 limit를 지정하는 메소드 실행하기 ================================");
		members = memberRepository.findTop2AllByOrderByEmailAsc(); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findFirst2AllByOrderByNameDesc(); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findTop1ByNameOrderByEmailAsc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findFirst1ByNameOrderByIdDesc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findTopByNameOrderByEmailAsc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findFirstByNameOrderByIdDesc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");

		System.out.println("정렬 기준을 다중으로 지정하는 메소드 실행하기 ===============================");
		members = memberRepository.findAllByOrderByEmailAscIdDesc(); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAllByOrderByNameDescEmailAscIdDesc(); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByNameOrderByEmailAscIdDesc("홍길동"); 
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		
		System.out.println("Sort 객체로 정렬 기준을 지정하는 메소드 실행하기 ============================");
		members = memberRepository.findAll(Sort.by(Direction.DESC, "name")); // 1차키
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAll(
			Sort.by(
				Order.desc("name"), // 1차키
				Order.asc("email")  // 2차키
			)
		);
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findAll(getSort());
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
		members = memberRepository.findByName("홍길동", getSort());
		members.forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
	private Sort getSort() {
		return Sort.by(
			Order.desc("name"), // 1차키
			Order.asc("email"), // 2차키
			Order.desc("id")    // 3차키
		);
	}
	
	@Test
	@Transactional
	void paging() {
		System.out.println("MemberRepositoryTest 클래스의 paging() 메소드 실행");

		System.out.println("페이징 메소드 실행하기 ======================================================");
//		PageRequest.of(얻어올 페이지 번호, 페이지 크기[, 정렬 방식])
//		Page<Member> pages = memberRepository.findAll(PageRequest.of(1, 4));
//		Page<Member> pages = memberRepository.findAll(PageRequest.of(1, 4, Sort.by(Direction.ASC, "name")));
//		Page<Member> pages = memberRepository.findAll(PageRequest.of(1, 4, Sort.by(Order.asc("name"), Order.desc("id"))));
		Page<Member> pages = memberRepository.findAll(PageRequest.of(1, 2, Sort.by(Order.desc("id"))));
		System.out.println("페이징 객체 >> " + pages);
		System.out.println("전체 데이터 개수 >> " + pages.getTotalElements()); // totalCount
		System.out.println("1페이지 크기 >> " + pages.getSize()); // pageSize
		System.out.println("전체 페이지 개수 >> " + pages.getTotalPages()); // totalPage
		System.out.println("현재 페이지 번호 >> " + pages.getNumber()); // currentPage
		System.out.println("현재 페이지의 데이터 개수 >> " + pages.getNumberOfElements());
		System.out.println("현재 페이지의 데이터 >> ");
		pages.getContent().forEach(System.out::println);
		System.out.println("정렬 여부 >> " + pages.getSort());
		System.out.println("=============================================================================");
		System.out.println("페이징 객체의 데이터 소유 여부 >> " + pages.hasContent());
		System.out.println("첫 페이지 여부 >> " + pages.isFirst());
		System.out.println("마지막 페이지 여부 >> " + pages.isLast());
		System.out.println("다음 페이지 존재 여부 >> " + pages.hasNext());
		System.out.println("이전 페이지 존재 여부 >> " + pages.hasPrevious());
		System.out.println("=============================================================================");
		
		int start = 0;
		int size = 0;
		Sort sort = null;
		Page<Member> page = null;
		
		pages = memberRepository.findAll(PageRequest.of(2, 2, Sort.by(Order.desc("id"))));
		System.out.println("현재 페이지 >> ");
		pages.getContent().forEach(System.out::println);
		if (pages.hasNext()) {
			System.out.println("다음 페이지가 있으면 다음 페이지 리턴 >> " + pages.nextPageable());
			start = pages.nextPageable().getPageNumber(); // 다음 페이지 번호를 얻어온다.
			size = pages.nextPageable().getPageSize(); // 1페이지의 크기를 얻어온다.
			sort = pages.nextPageable().getSort(); // 정렬 방식을 얻어온다.
			System.out.println(String.format("start: %d, size: %d, sort: %s", start, size, sort));
			page = memberRepository.findAll(PageRequest.of(start, size, sort));
			System.out.println("다음 페이지 >> ");
			page.getContent().forEach(System.out::println);
		} else {
			System.out.println("다음 페이지가 없으면 현재 페이지 리턴 >> " + pages.getPageable());
			start = pages.getPageable().getPageNumber();
			size = pages.getPageable().getPageSize();
			sort = pages.getPageable().getSort();
			System.out.println(String.format("start: %d, size: %d, sort: %s", start, size, sort));
			page = memberRepository.findAll(PageRequest.of(start, size, sort));
			System.out.println("현재 페이지 >> ");
			page.getContent().forEach(System.out::println);
		}
		
		pages = memberRepository.findAll(PageRequest.of(0, 2, Sort.by(Order.desc("id"))));
		System.out.println("현재 페이지 >> ");
		pages.getContent().forEach(System.out::println);
		if (pages.hasPrevious()) {
			System.out.println("이전 페이지가 있으면 이전 페이지 리턴 >> " + pages.previousPageable());
			start = pages.previousPageable().getPageNumber(); // 이전 페이지 번호를 얻어온다.
			size = pages.previousPageable().getPageSize(); // 1페이지의 크기를 얻어온다.
			sort = pages.previousPageable().getSort(); // 정렬 방식을 얻어온다.
			System.out.println(String.format("start: %d, size: %d, sort: %s", start, size, sort));
			page = memberRepository.findAll(PageRequest.of(start, size, sort));
			System.out.println("이전 페이지 >> ");
			page.getContent().forEach(System.out::println);
		} else {
			System.out.println("이전 페이지가 없으면 현재 페이지 리턴 >> " + pages.getPageable());
			start = pages.getPageable().getPageNumber();
			size = pages.getPageable().getPageSize();
			sort = pages.getPageable().getSort();
			System.out.println(String.format("start: %d, size: %d, sort: %s", start, size, sort));
			page = memberRepository.findAll(PageRequest.of(start, size, sort));
			System.out.println("현재 페이지 >> ");
			page.getContent().forEach(System.out::println);
		}
		System.out.println("=============================================================================");
		
		pages = memberRepository.findAll(PageRequest.of(2, 2, Sort.by(Order.desc("id"))));
		start = pages.nextOrLastPageable().getPageNumber();
		size = pages.nextOrLastPageable().getPageSize();
		sort = pages.nextOrLastPageable().getSort();
		page = memberRepository.findAll(PageRequest.of(start, size, sort));
		page.getContent().forEach(System.out::println);
		
		pages = memberRepository.findAll(PageRequest.of(0, 2, Sort.by(Order.desc("id"))));
		start = pages.previousOrFirstPageable() .getPageNumber();
		size = pages.previousOrFirstPageable().getPageSize();
		sort = pages.previousOrFirstPageable().getSort();
		page = memberRepository.findAll(PageRequest.of(start, size, sort));
		page.getContent().forEach(System.out::println);
		
		page = memberRepository.findByName("홍길동", PageRequest.of(0, 1, Sort.by(Order.desc("id"))));
		page.getContent().forEach(System.out::println);
	}
	
//	@Table, @Column, @Transient 어노테이션 테스트 메소드
	@Test
	@Transactional
	void insertAndUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 insertAndUpdateTest() 메소드 실행");

		System.out.println("@Table, @Column, @Transient 어노테이션 테스트 메소드 ========================");
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@tjoeun.com");
		member.setNickname("원숭이");
		memberRepository.save(member); // insert sql
		
		Member member2 = memberRepository.findById(1L).orElse(null);
		member2.setName("저팔계");
		memberRepository.save(member2); // update sql
		
		List<Member> members = memberRepository.findAll();
//		members.forEach(System.out::println);
		System.out.println("=============================================================================");
	}
	
//	@Enumerated 어노테이션 테스트 메소드
	@Test
	@Transactional
	void enumTest() {
		System.out.println("MemberRepositoryTest 클래스의 enumTest() 메소드 실행");
		
		System.out.println("@Enumerated 어노테이션 테스트 메소드 ========================================");
		Member member = memberRepository.findById(1L).orElse(null);
		member.setGender(Gender.MALE);
		memberRepository.save(member);
		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);
		
		Map<String, Object> map = memberRepository.findRawRecoed();
//		System.out.println(map.keySet());
//		System.out.println(map.values());
		for (String key : map.keySet()) {
			System.out.println(key + ": " + map.get(key));
		}
		System.out.println("=============================================================================");
	}
	
//	JPA가 제공하는 엔티티 이벤트 테스트 메소드
	@Test
	@Transactional
	void entityEventTest() {
		System.out.println("MemberRepositoryTest 클래스의 entityEventTest() 메소드 실행");

		System.out.println("JPA가 제공하는 엔티티 이벤트 테스트 메소드 ==================================");
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@tjoeun.com");
		member.setNickname("원숭이");
		memberRepository.save(member); // insert sql

		Member member2 = memberRepository.findById(1L).orElse(null);
		member2.setName("저팔계");
		memberRepository.save(member2); // update sql
		
		memberRepository.deleteById(2L); // delete sql
		
		List<Member> members = memberRepository.findAll(); // select sql
		members.forEach(System.out::println);		
		System.out.println("=============================================================================");
	}
	
//	@PrePersist 엔티티 이벤트 테스트 메소드
	@Test
	@Transactional
	void prePersistTest() {
		System.out.println("MemberRepositoryTest 클래스의 prePersistTest() 메소드 실행");
		
		System.out.println("@PrePersist 엔티티 이벤트 테스트 메소드 =====================================");
		Member member = new Member();
		member.setName("손오공");
		member.setEmail("son@tjoeun.com");
		member.setNickname("제천대성");
		member.setGender(Gender.MALE);
		
//		최초 저장 시간이나 수정 시간을 엔티티가 저장되거나 수정되는 시점에서 코딩하면 중복되는 코드가
//		여러 위치에 나타나므로 사소한 실수들을 유발할 수 있다.
//		member.setCreateAt(LocalDateTime.now()); // 최초 저장 시간
//		member.setUpdateAt(LocalDateTime.now()); // 최초 수정 시간
//		이 문제를 해결하기 위해 @PrePersist, @PreUpdate 어노테이션을 붙여서 선언한 이벤트에서 처리하는
//		것을 권장한다.
		
		memberRepository.save(member); // insert sql

		List<Member> members = memberRepository.findAll();
		members.forEach(System.out::println);		
		System.out.println("=============================================================================");
	}
	
	@Test
	@Transactional
	void preUpdateTest() {
		System.out.println("MemberRepositoryTest 클래스의 preUpdateTest() 메소드 실행");
		
		System.out.println("@PreUpdate 엔티티 이벤트 테스트 메소드 =====================================");
		Member member = memberRepository.findById(1L).orElse(null);
		System.out.println("수정전: " + member);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		member.setName("저팔계");
//		member.setUpdateAt(LocalDateTime.now()); // 수정 시간
		memberRepository.save(member); // update sql
//		member = memberRepository.findById(1L).orElse(null);
//		System.out.println("수정후: " + member);
		System.out.println("수정후: " + memberRepository.findAll().get(0));
		System.out.println("=============================================================================");
	}
	
}










