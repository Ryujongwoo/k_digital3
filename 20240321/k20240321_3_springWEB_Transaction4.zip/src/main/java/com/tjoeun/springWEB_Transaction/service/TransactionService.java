package com.tjoeun.springWEB_Transaction.service;

import com.tjoeun.springWEB_Transaction.vo.CardVO;

public interface TransactionService {

	public abstract void execute(CardVO cardVO);
	
}
