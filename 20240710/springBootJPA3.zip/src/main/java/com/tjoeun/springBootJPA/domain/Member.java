package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.PostRemove;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
//	@ToString
//	@EqualsAndHashCode
@Data

//	@Data 어노테이션을 사용하면 toString(), equals(), hashCode() 메소드를 롬복이 자동으로
//	만들어주는데 현재 클래스에 물리적으로 선언한 필드만 사용해서 만들어준다.
//	createAt, updateAt 필드는 BaseEntity 클래스에서 상속받아 사용을 하므로 롬복이 자동으로
//	만들어주지 못하기 때문에 부모 클래스의 toString(), equals(), hashCode() 메소드를 실행해서
//	만들게 해야 한다.
//	부모 클래스의 toString(), equals(), hashCode() 메소드를 실행하려면 @ToString, @EqualsAndHashCode
//	어노테이션에 callSuper = true 옵션을 지정해야 한다.
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)

@Builder
@Slf4j
@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
@Table(name = "member2", indexes = {@Index(columnList = "name")}, uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
//	@EntityListeners(value = MyEntityListener.class)
//	엔티티 이벤트 리스너가 2개 이상 사용되면 {}로 묶어서 ","로 구분해서 나열한다.
//	@EntityListeners(value = {MyEntityListener.class, MemberHistoryListener.class})
//	MyEntityListener 대신 springBoot가 제공하는 기본 엔티티 이벤트 리스너를 사용하기 위해서
//	MyEntityListener를 제거하고 AuditingEntityListener를 추가한다.
//	@EntityListeners(value = {AuditingEntityListener.class, MemberHistoryListener.class})

//	springBoot가 제공하는 기본 엔티티 이벤트 리스너(AuditingEntityListener)와 기본 엔티티 
//	이벤트 리스너를 사용하는 필드(createAt, updateAt)를 상속받았으므로 엔티티에서 제거한다.
@EntityListeners(value = MemberHistoryListener.class)
public class Member extends BaseEntity implements Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	@NonNull
	private String name;
	@NonNull
	private String email;
	@NonNull
	@Column(name = "nick", nullable = false, unique = true, length = 100)
	private String nickname;
	
//	springBoot가 제공하는 기본 엔티티 이벤트 리스너를 사용하기 위해 데이터 작성일 필드에는
//	@CreatedDate 어노테이션을 데이터 수정일 필드에는 @LastModifiedDate 어노테이션을 붙여준다.
//	@Column(updatable = false)
//	@CreatedDate
//	private LocalDateTime createAt;
//	@Column(insertable = false)
//	@LastModifiedDate
//	private LocalDateTime updateAt;
	
	@Transient
	private String testData;
	@Enumerated(value = EnumType.STRING)
	private Gender gender;
	
//	@PrePersist
//	public void prePersist() {
//		System.out.println("===== insert sql 명령 실행 전에 prePersist() 메소드 실행 =====");
//		createAt = LocalDateTime.now();
//		updateAt = LocalDateTime.now();
//	}
	
//	@PostPersist
//	public void postPersist() {
//		System.out.println("===== insert sql 명령 실행 후에 postPersist() 메소드 실행 =====");
//	}
	
//	@PostLoad
//	public void postLoad() {
//		System.out.println("===== select sql 명령 실행 후에 postLoad() 메소드 실행 =====");
//	}
	
//	@PreUpdate
//	public void preUpdate() {
//		System.out.println("===== update sql 명령 실행 전에 preUpdate() 메소드 실행 =====");
//		updateAt = LocalDateTime.now();
//	}
	
//	@PostUpdate
//	public void postUpdate() {
//		System.out.println("===== update sql 명령 실행 후에 postUpdate() 메소드 실행 =====");
//	}
	
//	@PreRemove
//	public void preRemove() {
//		System.out.println("===== delete sql 명령 실행 전에 preRemove() 메소드 실행 =====");
//	}
	
//	@PostRemove
//	public void postRemove() {
//		System.out.println("===== delete sql 명령 실행 후에 postRemove() 메소드 실행 =====");
//	}
	
}












