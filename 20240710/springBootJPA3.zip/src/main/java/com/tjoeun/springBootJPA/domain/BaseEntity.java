package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
//	@Entity 붙여서 선언한 클래스 이름과 필드 이름을 이용해서 JPA가 자동으로 테이블을 만들 때
//	테이블에는 클래스에서 선언한 필드만 테이블에 필드로 만든다.
//	@MappedSuperclass 어노테이션을 붙여주면 현재 클래스를 상속받아 작성된 엔티티가 테이블을
//	만들 때 필드로 포함시킨다.
@MappedSuperclass
//	springBoot가 제공하는 기본 엔티티 이벤트 리스너(AuditingEntityListener)를 적용하는 부분과
//	기본 엔티티 이벤트 리스너를 사용하는(@CreatedDate, @LastModifiedDate) 필드 부분을 구현해서
//	Member, MemberHistory, Book 엔티티에 상속시킨다.
@EntityListeners(value = AuditingEntityListener.class)
public class BaseEntity {

	@CreatedDate
	private LocalDateTime createAt;
	@LastModifiedDate
	private LocalDateTime updateAt;
	
}
