package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
//	@EntityListeners 어노테이션으로 엔티티 이벤트 리스너를 지정한다.
//	@EntityListeners(value = MyEntityListener.class)
//	MyEntityListener 대신 springBoot가 제공하는 기본 엔티티 이벤트 리스너를 사용하기 위해서
//	MyEntityListener를 제거하고 AuditingEntityListener를 추가한다.
//	@EntityListeners(value = AuditingEntityListener.class)
//	엔티티 이벤트 리스너를 적용할 엔티티 클래스에 Auditable 인터페이스를 구현한다.
//	Auditable 인터페이스의 추상 메소드 Override는 롬복이 자동으로 처리한다.

//	springBoot가 제공하는 기본 엔티티 이벤트 리스너(AuditingEntityListener)와 기본 엔티티 
//	이벤트 리스너를 사용하는 필드(createAt, updateAt)를 상속받았으므로 엔티티에서 제거한다.
public class Book extends BaseEntity implements Auditable {

	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	private String author;
	
//	springBoot가 제공하는 기본 엔티티 이벤트 리스너를 사용하기 위해 데이터 작성일 필드에는
//	@CreatedDate 어노테이션을 데이터 수정일 필드에는 @LastModifiedDate 어노테이션을 붙여준다.
//	@CreatedDate
//	private LocalDateTime createAt;
//	@LastModifiedDate
//	private LocalDateTime updateAt;
	
//	대부분의 엔티티는 작성일과 수정일을 저장하는 메소드가 필요할 것이다.
//	매번 엔티티를 생성할 때 마다 @PrePersist, @PreUpdate 어노테이션을 붙여서 엔티티 이벤트를 만들어
//	사용해도 되지만 같은 작업이 반복되므로 코드 리펙토링 차원에서 엔티티 리스너를 지정해서 사용하는
//	것을 권장한다.
	
//	엔티티 리스너를 지정해 사용할 것이므로 @PrePersist, @PreUpdate 어노테이션을 붙여서 구현한 엔티티
//	이벤트 메소드는 제거한다.
//	@PrePersist // 엔티티 이벤트
//	public void prePersist() {
//		createAt = LocalDateTime.now();
//		updateAt = LocalDateTime.now();
//	}
	
//	@PreUpdate // 엔티티 이벤트
//	public void preUpdate() {
//		updateAt = LocalDateTime.now();
//	}
	
}









