package com.tjoeun.springBootJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication

//	데이터 작성일과 수정일 저장은 매우 빈번하게 사용되는 기능이므로 springBoot는 데이터 작성일 과 수정일을
//	저장하는 기본 엔티티 이벤트 리스너를 제공한다.

//	기본 엔티티 이벤트 리스너를 사용하려면 main() 메소드가 생성된 클래스에 @EnableJpaAuditing 어노테이션을
//	붙여주고 데이터 작성일과 수정을 저장하던 엔티티 이벤트 리스너(MyEntityListener) 대신 springBoot가
//	제공하는 기본 엔티티 이벤트 리스너를 의미하는 AuditingEntityListener를 지정한다.
//	데이터 작성일 필드에는 @CreatedDate 어노테이션을 데이터 수정일 필드에는 @LastModifiedDate 어노테이션을
//	붙어주면 기본 리스너가 동작된다.
@EnableJpaAuditing
public class SpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaApplication.class, args);
	}

}
