package com.tjoeun.springBootJPA.support;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

//	엔티티 이벤트 리스너(MemberHistoryListener) 클래스는 @Autowired에 의해서 bean을 주입받지 못한다.
//	@Component 어노테이션을 붙여서 ApplicationContextAware 인터페이스를 구현받아 bean을 주입하는
//	객체를 만든다.
@Component
public class BeanUtils implements ApplicationContextAware {

	private static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		BeanUtils.applicationContext = applicationContext;
	}

	public static<T> T getBean(Class<T> clazz) {
		return applicationContext.getBean(clazz);
	}

}
