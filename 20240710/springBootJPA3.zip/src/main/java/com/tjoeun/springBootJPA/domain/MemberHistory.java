package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

//	Member 테이블에 입력 또는 수정된 히스토리를 저장할 엔티티를 선언한다.
@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
//	@EntityListeners(value = MyEntityListener.class)
//	MyEntityListener 대신 springBoot가 제공하는 기본 엔티티 이벤트 리스너를 사용하기 위해서
//	MyEntityListener를 제거하고 AuditingEntityListener를 추가한다.

//	springBoot가 제공하는 기본 엔티티 이벤트 리스너(AuditingEntityListener)와 기본 엔티티 
//	이벤트 리스너를 사용하는 필드(createAt, updateAt)를 상속받았으므로 엔티티에서 제거한다.
//	@EntityListeners(value = AuditingEntityListener.class)
public class MemberHistory extends BaseEntity implements Auditable {

	@Id
	@GeneratedValue
	private Long id;
	private Long userId; // Member 테이블에 입력 또는 수정된 user의 id
	private String name;
	private String email;
	
//	springBoot가 제공하는 기본 엔티티 이벤트 리스너를 사용하기 위해 데이터 작성일 필드에는
//	@CreatedDate 어노테이션을 데이터 수정일 필드에는 @LastModifiedDate 어노테이션을 붙여준다.
//	@CreatedDate
//	private LocalDateTime createAt;
//	@LastModifiedDate
//	private LocalDateTime updateAt;
	
}





