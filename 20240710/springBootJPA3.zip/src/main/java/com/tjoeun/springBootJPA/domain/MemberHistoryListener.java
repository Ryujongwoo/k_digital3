package com.tjoeun.springBootJPA.domain;

import com.tjoeun.springBootJPA.support.BeanUtils;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

public class MemberHistoryListener {

//	엔티티 이벤트 리스너(MemberHistoryListener) 클래스는 @Autowired에 의해서 자동으로 bean을
//	주입받지 못한다.
//	@Autowired
//	private MemberHistoryRepository memberHistoryRepository;
	
//	@PrePersist, @PreUpdate 어노테이션을 모두 사용해서 메소드를 만들면 insert, update sql 명령이
//	실행되기 전에 모두 메소드가 실행된다.
	@PrePersist
	@PreUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 클래스의 prePersistAndPreUpdate() 메소드 실행");
//		@Autowired를 사용하면 자동으로 bean을 주입받지 못하기 때문에 null이 출력된다.
//		bean을 주입하는 객체 BeanUtils를 사용해서 bean을 주입받는다.
		MemberHistoryRepository memberHistoryRepository = 
				BeanUtils.getBean(MemberHistoryRepository.class);
//		System.out.println(memberHistoryRepository);
		
		if (object instanceof Member) {
			Member member = (Member) object; // MemberHistory 테이블에 저장할 데이터
//			입력되거나 수정되서 데이터를 MemberHistory 테이블에 저장한다.
			MemberHistory memberHistory = new MemberHistory();
			memberHistory.setUserId(member.getId());
			memberHistory.setName(member.getName());
			memberHistory.setEmail(member.getEmail());
			memberHistoryRepository.save(memberHistory);
		}
	}
	
	
}
