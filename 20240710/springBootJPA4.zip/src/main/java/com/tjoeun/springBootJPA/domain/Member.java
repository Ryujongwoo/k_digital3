package com.tjoeun.springBootJPA.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Builder
@Slf4j
@Entity
@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
@Table(name = "member2", indexes = {@Index(columnList = "name")}, uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
@EntityListeners(value = MemberHistoryListener.class)
//	Auditable 인터페이스는 BaseEntity 클래스에 구현된 것을 상속받아 사용할 것이므로
//	Auditable 인터페이스 구현 부분을 제거한다.
public class Member extends BaseEntity /* implements Auditable */ {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	private Long id;
	@NonNull
	private String name;
	@NonNull
	private String email;
	@NonNull
	@Column(name = "nick", nullable = false, unique = true, length = 100)
	private String nickname;
	@Transient
	private String testData;
	@Enumerated(value = EnumType.STRING)
	private Gender gender;
	
}












