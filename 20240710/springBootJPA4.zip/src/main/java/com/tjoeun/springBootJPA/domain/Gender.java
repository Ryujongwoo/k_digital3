package com.tjoeun.springBootJPA.domain;

public enum Gender {

//	BABY,
	MALE,
	FEMALE
	
}
