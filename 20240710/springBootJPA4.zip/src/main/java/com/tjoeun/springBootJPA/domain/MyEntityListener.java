package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

public class MyEntityListener {

	@PrePersist
	public void prePersist(Object object) {
		System.out.println("MyEntityListener 클래스의 prePersist() 메소드 실행");
		if (object instanceof Auditable) {
			((Auditable) object).setCreateAt(LocalDateTime.now());
			((Auditable) object).setUpdateAt(LocalDateTime.now());
		}
	}
	
	@PreUpdate
	public void preUpdate(Object object) {
		System.out.println("MyEntityListener 클래스의 preUpdate() 메소드 실행");
		if (object instanceof Auditable) {
			((Auditable) object).setUpdateAt(LocalDateTime.now());
		}
	}
	
}
