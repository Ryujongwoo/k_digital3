package com.tjoeun.springBootJPA.domain;

import com.tjoeun.springBootJPA.support.BeanUtils;

import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

public class MemberHistoryListener {

	@PrePersist
	@PreUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 클래스의 prePersistAndPreUpdate() 메소드 실행");
		MemberHistoryRepository memberHistoryRepository = 
				BeanUtils.getBean(MemberHistoryRepository.class);
		
		if (object instanceof Member) {
			Member member = (Member) object;
			MemberHistory memberHistory = new MemberHistory();
			memberHistory.setUserId(member.getId());
			memberHistory.setName(member.getName());
			memberHistory.setEmail(member.getEmail());
			memberHistoryRepository.save(memberHistory);
		}
	}
	
}
