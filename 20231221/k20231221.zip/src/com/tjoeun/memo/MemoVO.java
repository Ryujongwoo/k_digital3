package com.tjoeun.memo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MemoVO {

	private int idx;
	private String name;
	private String password;
	private String memo;
	private Date writeDate = new Date();
	
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Date getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}
	
	@Override
	public String toString() {
		
//		오늘 입력된 메모는 시간만 표시하고 어제 이전에 입력된 메모는 날짜만 표시한다.
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd(E) HH:mm:ss.SSS");
		return String.format("%d. %s(%s)님이 %s에 남긴글\n%s", idx, name, password, sdf.format(writeDate), memo);
		
	}
	
}








