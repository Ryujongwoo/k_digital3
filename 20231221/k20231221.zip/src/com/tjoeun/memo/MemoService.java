package com.tjoeun.memo;

import java.util.ArrayList;
import java.util.Scanner;

//	데이터를 테이블에 저장, 테이블에 저장된 데이터를 수정, 삭제 및 조회 작업을 실행하기 전에
//	필요한 전처리 작업을 실행하는 클래스 => 비즈니스 로직을 작성하는 클래스
public class MemoService {

//	데이터를 입력받아 DAO 클래스로 넘겨주는 메소드
	public static void insert() {
		
		System.out.println("MemoService 클래스의 insert() 메소드 실행");
		
//		전처리
//		테이블에 저장할 데이터를 키보드로 입력받는다.
		Scanner scanner = new Scanner(System.in);
		System.out.println("테이블에 저장할 데이터 입력");
		System.out.print("이름: ");
		String name = scanner.nextLine().trim();
		System.out.print("비밀번호: ");
		String password = scanner.nextLine().trim();
		System.out.print("메모: ");
		String memo = scanner.nextLine().trim();

//		입력받은 데이터를 MemoVO 클래스 객체를 만들어 저장한다.
		MemoVO vo = new MemoVO();
		vo.setName(name);
		vo.setPassword(password);
		vo.setMemo(memo);
//		System.out.println(vo);
		
//		입력받은 데이터를 테이블에 저장하는 MemoDAO 클래스의 메소드를 호출한다.
		boolean result = MemoDAO.insert(vo);
		
//		후처리
		if (result) {
			System.out.println(name + "님 글 저장완료");
		} else {
			System.out.println("sql 명령이 올바르게 실행되지 않았습니다.");
		}
		
	}
	
//	저장된 글 목록을 최신글 부터 얻어오는 메소드
	public static void select() {
		
		System.out.println("MemoService 클래스의 select() 메소드 실행");
		
//		테이블에 저장된 메모 목록을 글번호(idx)의 내림차순(최신글순)으로 얻어오는 메소드를 호출한다.
		ArrayList<MemoVO> list = MemoDAO.select();
		
//		얻어온 메모 목록을 콘솔에 출력한다.
		if (list == null || list.size() == 0) {
			System.out.println("테이블에 저장된 메모가 없습니다.");
		} else {
			for (MemoVO vo : list) {
				System.out.println(vo);
			}
		}
		
	}
	
//	수정할 글번호를 넘겨받아 테이블의 글을 수정하는 메소드
	
//	삭제할 글번호를 넘겨받아 테이블의 글을 삭제하는 메소드
	
}












