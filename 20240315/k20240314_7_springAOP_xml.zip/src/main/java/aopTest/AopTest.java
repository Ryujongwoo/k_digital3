package aopTest;

public class AopTest {

	public void aopTest() {
		System.out.println("AopTest 클래스의 핵심 기능");
	}
	
}
