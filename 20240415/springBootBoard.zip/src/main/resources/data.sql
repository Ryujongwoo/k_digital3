-- article 테이블 더미 데이터
insert into article(id, title, content) values (1, '당신의 인생 드라마는?', '댓글');
insert into article(id, title, content) values (2, '당신의 소울 푸드는?', '댓글');
insert into article(id, title, content) values (3, '당신의 취미는?', '댓글');
insert into article(id, title, content) values (4, '당신의 최애 스포츠는?', '댓글');

-- comment 테이블 더미 데이터
-- 1번 메인글 댓글
insert into comment(id, article_id, nickname, body) values (1, 1, '홍길동', '태양의 후예');
insert into comment(id, article_id, nickname, body) values (2, 1, '임꺽정', '태왕 사신기');
insert into comment(id, article_id, nickname, body) values (3, 1, '장길산', '응답하라 1994');

-- 2번 메인글 댓글
insert into comment(id, article_id, nickname, body) values (4, 2, '홍길동', '초밥');
insert into comment(id, article_id, nickname, body) values (5, 2, '임꺽정', '쌀국수');
insert into comment(id, article_id, nickname, body) values (6, 2, '장길산', '돈까스');

-- 3번 메인글 댓글
insert into comment(id, article_id, nickname, body) values (7, 3, '홍길동', '등산');
insert into comment(id, article_id, nickname, body) values (8, 3, '임꺽정', '바둑');
insert into comment(id, article_id, nickname, body) values (9, 3, '장길산', '낚시');