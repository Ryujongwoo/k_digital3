package com.tjoeun.springBootBoard.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tjoeun.springBootBoard.dto.CommentDto;
import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.entity.Comment;
import com.tjoeun.springBootBoard.repository.ArticleRepository;
import com.tjoeun.springBootBoard.repository.CommentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CommentService {

//	ArticleRepository와 CommentRepository 인터페이스의 JPA 메소드를 사용하기 위해
//	ArticleRepository와 CommentRepository 인터페이스의 bean을 가져온다.
	@Autowired
	private ArticleRepository articleRepository;
	@Autowired
	private CommentRepository commentRepository;
	
//	메인글의 id에 따른 댓글 목록 조회	
	public List<CommentDto> comments(Long articleId) {
		log.info("CommentService 클래스의 comments() 메소드 실행");
		log.info("articleId = {}", articleId);
		
		/*
//		메인글의 글번호에 따른 댓글 목록 조회
		List<Comment> comments = commentRepository.findByArticlaId(articleId);
		
//		Comment 엔티티 객체를 CommentDto 객체로 변환한다.
		List<CommentDto> commentDtos = new ArrayList<CommentDto>();
//		for (int i=0; i<comments.size(); i++) {
//			Comment 엔티티 객체를 CommentDto 객체로 변환하는 메소드를 호출한다.
//			Comment comment = comments.get(i);
//			CommentDto commentDto = CommentDto.createCommentDto(comment);
//			commentDtos.add(commentDto);
//		}
		for (Comment comment : comments) {
			CommentDto commentDto = CommentDto.createCommentDto(comment);
			commentDtos.add(commentDto);
		}
		return commentDtos;
		*/
		
//		stream 활용
		return commentRepository.findByArticlaId(articleId)
			.stream()
			.map(comment -> CommentDto.createCommentDto(comment))
			.collect(Collectors.toList());
	}

//	댓글 입력
//	댓글 입력에 실패하면 실행전 상태로 되돌려야 하므로 트랜잭션 처리를 해야한다.
	@Transactional
	public CommentDto create(Long articleId, CommentDto commentDto) {
		log.info("CommentService 클래스의 create() 메소드 실행");
		log.info("articleId = {}, commentDto = {}", articleId, commentDto);
		
//		댓글을 저장하려는 메인글이 없으면 예외를 발생시킨다.
		Article article = articleRepository.findById(articleId).orElseThrow(
			() -> new IllegalArgumentException("댓글 저장 실패!!! 메인글이 없습니다.")
		);
		
//		댓글 엔티티를 생성한다.
		Comment comment = Comment.createComment(article, commentDto);
		log.info("comment = {}", comment);
//		댓글 엔티티를 테이블에 저장한다.
		Comment saved = commentRepository.save(comment);
//		실행(댓글 저장) 결과(Comment 엔티티)를 CommentDto 타입으로 변환해서 리턴시킨다.
		return CommentDto.createCommentDto(saved);
	}

//	댓글 수정
//	댓글 수정에 실패하면 실행전 상태로 되돌려야 하므로 트랜잭션 처리를 해야한다.
	@Transactional
	public CommentDto update(Long id, CommentDto commentDto) {
		log.info("CommentService 클래스의 update() 메소드 실행");
		log.info("id = {}, commentDto = {}", id, commentDto);
		
//		수정할 댓글이 없으면 예외를 발생시킨다.
		Comment comment = commentRepository.findById(id).orElseThrow(
			() -> new IllegalArgumentException("댓글 수정 실패!!! 수정할 댓글이 없습니다.")
		);
		
//		댓글을 수정하는 메소드를 호출한다.
		comment.patch(commentDto);
//		수정된 댓글을 저장하는 메소드를 호출한다.
		Comment updated = commentRepository.save(comment);
//		실행(댓글 수정) 결과(Comment 엔티티)를 CommentDto 타입으로 변환해서 리턴시킨다.
		return CommentDto.createCommentDto(updated);
	}

//	댓글 삭제
//	댓글 삭제에 실패하면 실행전 상태로 되돌려야 하므로 트랜잭션 처리를 해야한다.
	@Transactional
	public CommentDto delete(Long id) {
		log.info("CommentService 클래스의 delete() 메소드 실행");
		log.info("id = {}", id);
		
//		삭제할 댓글이 없으면 예외를 발생시킨다.
		Comment comment = commentRepository.findById(id).orElseThrow(
			() -> new IllegalArgumentException("댓글 삭제 실패!!! 수정할 댓글이 없습니다.")
		);

//		댓글을 삭제하는 메소드를 호출한다.
		commentRepository.delete(comment);
//		실행(댓글 삭제) 결과(Comment 엔티티)를 CommentDto 타입으로 변환해서 리턴시킨다.
		return CommentDto.createCommentDto(comment);
	}
	
}










