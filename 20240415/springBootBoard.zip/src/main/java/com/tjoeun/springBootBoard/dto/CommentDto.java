package com.tjoeun.springBootBoard.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tjoeun.springBootBoard.entity.Comment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Slf4j
public class CommentDto { // 댓글 1건을 기억하는 클래스

	private Long id;
//	@JsonProperty 어노테이션을 사용하면 받을 데이터가 저장된 자바스크립트(JSON) 변수를 지정할 수 있다.
//	@JsonProperty("article_id")
	private Long articleId;
	private String nickname;
	private String body;
	
//	Comment 엔티티를 CommentDto 클래스 객체로 만드는 메소드
	public static CommentDto createCommentDto(Comment comment) {
		log.info("CommentDto 클래스의 createCommentDto() 메소드 실행");
		log.info("comment = {}", comment);
		return new CommentDto(
			comment.getId(), comment.getArticle().getId(), comment.getNickname(), comment.getBody()
		);
	}
	
}
