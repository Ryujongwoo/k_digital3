-- ���α� ���̺�
CREATE TABLE "FREEBOARD" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"SUBJECT" VARCHAR2(200 BYTE) NOT NULL, 
	"CONTENT" VARCHAR2(3000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"HIT" NUMBER(*,0) DEFAULT 0, 
	"NOTICE" CHAR(2 BYTE) DEFAULT '', 
	"IP" CHAR(15 BYTE), 
	CONSTRAINT "FREEBOARD_PK" PRIMARY KEY ("IDX")
);

-- ���α� ������
DELETE FROM freeboard;
DROP SEQUENCE freeboard_idx_seq;
CREATE SEQUENCE freeboard_idx_seq;

insert into freeboard (idx, name, password, subject, content, notice, ip) 
values (freeboard_idx_seq.nextval, 'ȫ�浿', '1111', '1��', '1�� �Դϴ�.', '', '192.168.100.101');
insert into freeboard (idx, name, password, subject, content, notice, ip) 
values (freeboard_idx_seq.nextval, '�Ӳ���', '2222', '2��', '2�� �Դϴ�.', '', '192.168.100.102');
insert into freeboard (idx, name, password, subject, content, notice, ip) 
values (freeboard_idx_seq.nextval, '����', '3333', '3��', '3�� �Դϴ�.', '', '192.168.100.103');
insert into freeboard (idx, name, password, subject, content, notice, ip) 
values (freeboard_idx_seq.nextval, '������', '4444', '4��', '4�� �Դϴ�.', '', '192.168.100.104');

commit;

select * from freeboard order by idx desc;
select count(*) from freeboard;

-- ��� ���̺�
CREATE TABLE "FREEBOARDCOMMENT" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"GUP" NUMBER(*,0), 
	"NAME" CHAR(20 BYTE) NOT NULL, 
	"PASSWORD" CHAR(20 BYTE) NOT NULL, 
	"CONTENT" VARCHAR2(1000 BYTE) NOT NULL, 
	"WRITEDATE" TIMESTAMP (6) DEFAULT sysdate, 
	"IP" CHAR(15 BYTE), 
	CONSTRAINT "FREEBOARDCOMMENT_PK" PRIMARY KEY ("IDX")
);

-- ��� ������
DELETE FROM freeboardcomment;
DROP SEQUENCE freeboardcomment_idx_seq;
CREATE SEQUENCE freeboardcomment_idx_seq;












