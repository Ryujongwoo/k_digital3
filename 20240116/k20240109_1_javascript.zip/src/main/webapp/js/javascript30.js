function singleArray() {
//	배열 선언 방법
//	let 배열명 = new Array() // 크기가 0인 빈 배열 객체를 선언한다.
	let arrayObj = new Array()
	console.log(arrayObj)
	console.log(typeof arrayObj)
	console.log(arrayObj.length)
	console.log('=======================')

//	let 배열명 = [] // 크기가 0인 빈 배열 객체를 선언한다.
	let arrayObj2 = []
	console.log(arrayObj2)
	console.log(typeof arrayObj2)
	console.log(arrayObj2.length)
	console.log('=======================')
	
//	let 배열명 = new Array(크기) // 빈 배열 객체를 크기를 지정해서 선언한다.
	let arrayObj3 = new Array(5)
	console.log(arrayObj3)
	console.log(typeof arrayObj3)
	console.log(arrayObj3.length)
	console.log('=======================')
	
//	초기치의 개수 만큼 크기를 가지는 배열 객체를 선언하고 초기치로 초기화시킨다.
//	let 배열명 = new Array(초기치)
//	let 배열명 = [초기치]
//	let arrayObj4 = new Array(1, 2, 3, 4, 5)
	let arrayObj4 = [5, 4, 3, 2, 1]
	console.log(arrayObj4)
	console.log(typeof arrayObj4)
	console.log(arrayObj4.length)
	console.log('=======================')
	
	let arrayObj5 = ['java', 2, 'script', 4]
	console.log(arrayObj5)
	console.log(typeof arrayObj5)
	console.log(arrayObj5.length)
}

function multiArray() {
	let arrRow = 4 // 행의 개수
	let arrCol = 3 // 열의 개수
	
//	행을 먼저 만들고 행의 개수만큼 반복하며 열을 만든다.
	let arr = new Array(arrRow) // 행을 만든다.
	for (let i = 0; i<arrRow; i++) { // 행의 개수만큼 반복한다.
		arr[i] = new Array(arrCol) // 각각의 행에 열을 만든다.
	}
	
//	2차원 배열의 각 인덱스에 접근하려면 배열명[행][열] 형태로 접근한다.
	arr[0][0] = 'apple'
	arr[0][1] = 'banana'
	arr[0][2] = 'melon'
	
	arr[1][0] = 100
	arr[1][1] = 200
	arr[1][2] = 300
	
	arr[2][0] = true
	arr[2][1] = 999
	arr[2][2] = '홍길동'
	
//	배열에 배열을 저장시킬 수 있다.
	arr[3][0] = ['임꺽정', '바보'] // 3차원, 배열명[면][행][열]
	arr[3][1] = ['장길산', '천재']
	arr[3][2] = ['코로나는', '전 국민이 다 걸려서 끝났어요']
	
	console.log(arr)
	console.log(arr[0])
	console.log(arr[3][0])
	console.log(arr[3][2][1])
	
	let arr2 = [[1, 2], [3, 4], [5, 6]]
	console.log(arr2)
}

function joinTest() {
	let fruits = ['apple', 'banana', 'melon', 'mango']
	let numbers = ['111', '222', '333', '444']
	
//	배열을 합치고 싶어서 덧셈 연산을 하면 각각의 배열 요소는 ','로 구분된 문자열을 만들어서 합친다.
	let add = fruits + numbers
	console.log(add) // apple,banana,melon,mango111,222,333,444
	console.log(typeof add) // string
	
//	2개 이상의 배열을 합치려면 concat() 함수를 사용해야 한다.
	let result = fruits.concat(numbers)
	console.log(result) // ['apple', 'banana', 'melon', 'mango', '111', '222', '333', '444']
	console.log(typeof result) // object
	
//	join() 함수는 배열 요소 사이에 인수로 지정한 문자열을 삽입해서 문자열로 만든다.
	let result2 = fruits.join(',')
	console.log(result2) // apple,banana,melon,mango
	console.log(typeof result2) // string
}






























