function searchID() {
	let doc = document.getElementById('test')
	console.log(doc)
	console.log(doc.length)
	doc.innerHTML += '<br/>getElementById() 함수는 DOM에서 id 속성을 선택한다.'
	doc.style.backgroundColor = 'yellow'
}

function searchName() {
	let docs = document.getElementsByName('test')
	console.log(docs)
	console.log(docs.length)
	
//	docs[0].value = '홍길동'
//	docs[1].value = '임꺽정'
//	docs[2].value = '장길산'
	
	const names = ['홍길동', '임꺽정', '장길산']
	
//	for (let i = 0; i<docs.length; i++) {
//		docs[i].value = names[i]
//	}

//	let i = 0
//	for (let doc of docs) {
//		doc.value = names[i++]
//	}

//	for (let i in docs) {
//		docs[i].value = names[i]
//	}

//	배열명.forEach(변수[, 인덱스])
//	변수에는 배열에 저장된 각 인덱스의 데이터가 차례대로 넘어가고 인덱스에는 변수에 저장되는 데이터의 인덱스가
//	저장된다.
//	DOM 선택 함수 중에서 getElementsByName()은 NodeList 객체로 얻어오고 getElementsByTagName()과
//	getElementsByClassName()은 HTMLCollection 객체로 얻어온다.
//	HTMLCollection 객체에는 forEach() 함수를 사용할 수 없다.
//	docs.forEach(function (doc, i) {
//		console.log(doc + ', ' + i)
//		doc.value = names[i]
//	})

	docs.forEach((doc, i) => doc.value = names[i])
}

function searchTagName() {
	let docs = document.getElementsByTagName('p')
	console.log(docs)
	console.log(docs.length)
	
	for (let doc of docs) {
		doc.style.backgroundColor = 'hotpink'
	}
//	docs.forEach((doc, i) => doc.style.backgroundColor = 'hotpink') // 에러 발생
}

function searchClass() {
	let docs = document.getElementsByClassName('test')
	console.log(docs)
	console.log(docs.length)	
	
	for (let doc of docs) {
		doc.style.backgroundColor = 'skyblue'
	}
//	docs.forEach((doc, i) => doc.style.backgroundColor = 'skyblue') // 에러 발생
}

function searchCSSSelector() {
//	id 속성으로 탐색
//	querySelector('#id속성값')
	let doc = document.querySelector('#test')
	console.log(doc)
	doc.innerHTML = 'querySelector로 id 탐색'
	doc.style.color = 'red'
	doc.style.backgroundColor = 'skyblue'
	
//	class 속성으로 탐색
//	querySelectorAll('.class속성값')
	let docs = document.querySelectorAll('.test')
	console.log(docs)
//	for (let doc of docs) {
//		doc.innerHTML = 'querySelectorAll로 class 탐색'
//		doc.style.color = 'yellow'
//		doc.style.backgroundColor = 'black'
//	}
	docs.forEach(doc => {
		doc.innerHTML = 'querySelectorAll로 class 탐색'
		doc.style.color = 'yellow'
		doc.style.backgroundColor = 'black'
	})
	
//	tag 이름으로 선택
//	querySelectorAll('tag이름')
	docs = document.querySelectorAll('p')
	console.log(docs)
//	for (let doc of docs) {
//		doc.innerHTML = 'querySelectorAll로 tag 탐색'
//		doc.style.color = 'green'
//		doc.style.backgroundColor = 'tomato'
//	}
	docs.forEach(doc => {
		doc.innerHTML = 'querySelectorAll로 tag 탐색'
		doc.style.color = 'green'
		doc.style.backgroundColor = 'tomato'
	})
}

