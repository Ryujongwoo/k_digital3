package com.tjoeun.myCalendar;

import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SolaToLunar2 {

	public static ArrayList<LunarDate> solaToLunar(int year, int month) {
		ArrayList<LunarDate> lunarList = new ArrayList<LunarDate>();
		String targetSite = "";
		
		for (int i=1; i<=12; i++) {
//			targetSite = String.format(
//				"https://astro.kasi.re.kr/life/pageView/5?search_year=%04d&search_month=%02d&search_check=G", 
//				year, i);
//			System.out.println(targetSite);
			
//			크롤링한 데이터를 기억할 org.jsoup.nodes 패키지의 Document 클래스 객체를 선언한다.
			Document document = null;
			try {
				Response response = Jsoup.connect("https://astro.kasi.re.kr/life/pageView/5")
						.userAgent("Mozilla/7.0")
						.method(Method.POST)
						.data("search_year", String.format("%04d", year))
						.data("search_month", String.format("%02d", i))
						.data("search_check", "G")
						.followRedirects(true)
						.execute();
				
//				document = Jsoup.connect(targetSite).get();
				document = response.parse();
//				System.out.println(document);
				Elements elements = document.select("tbody > tr");
//				System.out.println(elements);
				for (Element element : elements) {
//					System.out.println(element);
//					System.out.println("==============================================================");
					Elements ele = element.select("td");
//					System.out.println(ele);
					
					String sola = ele.get(0).text();
					String lunar = ele.get(1).text();
					System.out.println(String.format("양력 %s은 음력으로 %s 입니다.", sola, lunar));
					
					LunarDate lunarDate = new LunarDate();
					lunarDate.setYear(year);
					
//					System.out.println(lunarDate);
				}
				
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("targetSite 주소가 올바르지 않거나 targetSite에 문제가 있습니다.");
			}
			
//			공휴일 처리
			
		}
		
		return null;
	}
	
}











