package com.tjoeun.springBootJPA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tjoeun.springBootJPA.domain.BookReviewInfo;

public interface BookReviewInfoRepository extends JpaRepository<BookReviewInfo, Long> {

}
