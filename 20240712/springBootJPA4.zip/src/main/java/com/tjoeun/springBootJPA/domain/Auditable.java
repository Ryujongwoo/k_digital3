package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

public interface Auditable {

	void setCreateAt(LocalDateTime createAt);
	void setUpdateAt(LocalDateTime updateAt);
	
}
