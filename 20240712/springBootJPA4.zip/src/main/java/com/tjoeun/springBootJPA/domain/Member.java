package com.tjoeun.springBootJPA.domain;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Builder
@Slf4j
@Entity
//	@SequenceGenerator(name = "seq_generator", sequenceName = "member_id_seq", initialValue = 1, allocationSize = 1)
@Table(name = "member2", indexes = {@Index(columnList = "name")}, uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
@EntityListeners(value = MemberHistoryListener.class)
//	Auditable 인터페이스는 BaseEntity 클래스에 구현된 것을 상속받아 사용할 것이므로
//	Auditable 인터페이스 구현 부분을 제거한다.
public class Member extends BaseEntity /* implements Auditable */ {

	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
//	id 값을 MYSQL, MariaDB와 같이 auto_increment를 이용해서 증가하게 한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@NonNull
	private String name;
	@NonNull
	private String email;
	@NonNull
	@Column(name = "nick", nullable = false, unique = true, length = 100)
	private String nickname;
	@Transient
	private String testData;
	@Enumerated(value = EnumType.STRING)
	private Gender gender;
	
//	@OneToMany 어노테이션으로 1:N 연관 관계를 설정한다.
//	지연 로딩
//	데이터가 필요한 시점에서 연관된 데이터를 불러오는 것을 의미한다.
//	@OneToMany 어노테이션만 사용하거나 fetch 옵션을 FetchType.LAZY로 지정하면 지연 로딩을 한다.
//	지연 로딩을 하면 LazyInitializationException(지연 초기화)가 발생될 수 있고 지연 초기화가 
//	발생되면 테스트 메소드에 @Transactional 어노테이션을 붙여주거나 @OneToMany 어노테이션의
//	fetch 옵션을 FetchType.EAGER로 지정하면 해결할 수 있다.
//	@OneToMany
//	@OneToMany(fetch = FetchType.LAZY) // 기본값
//	즉시 로딩
//	데이터 조회시 연관된 데이터까지 한 번에 불러오는 것을 의미한다.
	@OneToMany(fetch = FetchType.EAGER)
//	@JoinColumn 어노테이션은 현재 엔티티가 어떤 필드와 join 하게될지 지정한다.
//	@OneToMany 어노테이션으로 1:N 연관 관계를 설정은 중간 테이블을 만들지 못하도록 @JoinColumn
//	어노테이션의 name 속성값을 "user_id"로 지정해서 "member_history" 테이블의 "user_id" 필드와 
//	join 됨을 지정한다.
//	Member 엔티티의 기본키와 연결될 MemberHistory 엔티티의 외래키 필드를 지정한다.
	@JoinColumn(name = "user_id")
//	Member 엔티티와 MemberHistory 엔티티는 1:N 관계이므로 Member 엔티티에 관련된 MemberHistory 
//	엔티티가 여러개이기 때문에 Collection(List, Set, Map) 타입으로 선언한다.
	private List<MemberHistory> memberHistories = new ArrayList<>();
	
}












