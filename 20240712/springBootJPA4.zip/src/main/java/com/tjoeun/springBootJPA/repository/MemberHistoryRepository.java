package com.tjoeun.springBootJPA.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tjoeun.springBootJPA.domain.MemberHistory;

public interface MemberHistoryRepository extends JpaRepository<MemberHistory, Long> {

//	특정 userId에 해당되는 데이터만 가져오는 쿼리 메소드를 만든다.
	public List<MemberHistory> findByUserId(Long userId);
	
}
