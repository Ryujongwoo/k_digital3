package com.tjoeun.springBootJPA.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
//	Auditable 인터페이스는 BaseEntity 클래스에 구현된 것을 상속받아 사용할 것이므로
//	Auditable 인터페이스 구현 부분을 제거한다.
public class Book extends BaseEntity /* implements Auditable */ {

	@Id
//	@GeneratedValue
//	id 값을 MYSQL, MariaDB와 같이 auto_increment를 이용해서 증가하게 한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id; // PK
	private String name;
//	private String author; // 제거
	private String category; // 추가
	private Long authorId; // 추가
	private Long publisherId; // 추가
//	createAt, updateAt 필드는 BaseEntity 클래스에서 상속받아 사용한다.
//	BaseEntity 클래스에 @MappedSuperclass 어노테이션이 지정되어 있으므로 BaseEntity 클래스를
//	상속받아 만드는 BookReviewInfo 엔티티에 BaseEntity 클래스에서 정의한 필드가 테이블에 생성된다.
//	private LocalDateTime createAt;
//	private LocalDateTime updateAt;
	
//	특별한 경우가 아니라면 1:1 연관 관계 설정은 단방향으로 걸어서 사용한다.
//	1:1 연관 관계를 설정해서 Book 엔티티에서 BookReviewInfo 엔티티를 직접 참조하게 설정한다.
	@OneToOne
//	@OneToOne(optional = true)
//	@OneToOne(optional = false)
//	mappedBy = "엔티티 클래스 이름" 옵션을 지정하면 해당 엔티티는 외래키를 생성하지 않는다.
//	mappedBy 옵션을 지정하면 외래키를 만들지 않기 때문에 optional 옵션이 의미가 없어진다.
//	@OneToOne(mappedBy = "book")
//	toString() 메소드에서 순환 참조 문제로 StackOverflowError가 발생되면 @ToString.Exclude를
//	넣어서 toString() 메소드를 제외시키고 실행하면 된다.
//	@ToString.Exclude
//	Book 엔티티에서 BookReviewInfo 엔티티를 직접 참조하게 설정할 것이므로 참조할 BookReviewInfo
//	엔티티 객체를 선언한다.
//	book 테이블에는 book_review_info_id 라는 필드가 만들어진다.
	private BookReviewInfo bookReviewInfo;

}









