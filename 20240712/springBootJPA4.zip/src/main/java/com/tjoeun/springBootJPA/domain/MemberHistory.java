package com.tjoeun.springBootJPA.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
//	Auditable 인터페이스는 BaseEntity 클래스에 구현된 것을 상속받아 사용할 것이므로
//	Auditable 인터페이스 구현 부분을 제거한다.
public class MemberHistory extends BaseEntity /* implements Auditable */ {

	@Id
//	@GeneratedValue
//	id 값을 MYSQL, MariaDB와 같이 auto_increment를 이용해서 증가하게 한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
//	MemberHistory 엔티티에 선언한 필드 "userId"는 테이블에는 "user_id"로 저장되므로 외래키 연결을
//	위해서 Member 엔티티의 @JoinColumn 어노테이션의 name 속성에서 지정한 이름으로 @Column 어노테이션의
//	name 속성으로 지정한다.
	@Column(name = "user_id")
	private Long userId; // Member 엔티티를 참조할 외래키로 사용될 필드
	private String name;
	private String email;
	
//	@ManyToOne 어노테이션으로 N:1 연관 관계를 설정할 수 있다.
	@ManyToOne
//	toString() 메소드가 꼬여서 Stack Overflow가 발생되서 정상적으로 처리되지 않기 때문에
//	@ToString.Exclude를 붙여서 롬복이 자동으로 만들어준 toString() 메소드를 제외하고 시행한다. 
	@ToString.Exclude
//	MemberHistory 엔티티와 Member 엔티티는 N:1 관계이므로 MemberHistory 엔티티에 관련된 Member
//	엔티티는 1개이기 때문에 객체로 선언한다.
	private Member member;
	
//	N:1 연관 관계를 설정하기 위해 MemberHistory 엔티티에 추가한 Member 엔티티 객체에 데이터를
//	넣어주는 작업을 엔티티 이벤트 리스너(MemberHistoryListener)에서 추가해야 한다.

}





