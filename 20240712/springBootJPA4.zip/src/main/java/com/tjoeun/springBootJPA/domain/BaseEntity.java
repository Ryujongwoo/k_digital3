package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@MappedSuperclass
@EntityListeners(value = AuditingEntityListener.class)
//	Member, MemberHistory, Book 엔티티 모두 Auditable 인터페이스를 구현받아 만든다.
//	Auditable 인테페이스를 BaseEntity 클래스가 구현받게 하고 BaseEntity 클래스를
//	Member, MemberHistory, Book 엔티티가 상속받아 엔티티 이벤트 리스너를 처리한다.
public class BaseEntity implements Auditable {

	@CreatedDate
	private LocalDateTime createAt;
	@LastModifiedDate
	private LocalDateTime updateAt;
	
}
