package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
public class BookReviewInfo extends BaseEntity {

	@Id
//	@GeneratedValue
//	id 값을 MYSQL, MariaDB와 같이 auto_increment를 이용해서 증가하게 한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
//	필드의 데이터 타입을 기본 자료형(float, int)을 사용하면 null 값을 허용하지 않는다.
//	필드의 데이터 타입을 랩퍼 클래스(Float, Integer)를 사용하면 null 값을 허용한다.
	private float averageReviewScore;
	private int reviewCount;
//	createAt, updateAt 필드는 BaseEntity 클래스에서 상속받아 사용한다.
//	BaseEntity 클래스에 @MappedSuperclass 어노테이션이 지정되어 있으므로 BaseEntity 클래스를
//	상속받아 만드는 BookReviewInfo 엔티티에 BaseEntity 클래스에서 정의한 필드가 테이블에 생성된다.
//	private LocalDateTime createAt;
//	private LocalDateTime updateAt;
	
//	book 테이블의 기본키인 id 필드를 참조하는 외래키 필드를 선언한다.
	private Long bookIdx; // FK
	
//	@OneToOne 어노테이션으로 1:1 연관 관계를 설정할 수 있다.
//	1:1 연관 관계를 설정해서 BookReviewInfo 엔티티에서 Book 엔티티를 직접 참조하게 설정한다.
//	@OneToOne 어노테이션만 사용하거나 optional = true 옵션을 지정하면 아래와 같이 create sql
//	명령이 실행되며 테이블이 만들어진다.
	@OneToOne
//	@OneToOne(optional = true) // 생략시 기본값
//	create table book_review_info (
//		...
//		자동으로 추가된 외래키 필드(book_id)가 null 값을 허용하고 내부적으로 left outer join이
//		걸려서 왼쪽 테이블은 내용이 있을 수도 있고 없을 수도 있는 값, 오른쪽 테이블은 반드시
//		존재하는 값을 얻어온다.
//		테이블을 만들때 외래키로 사용될 필드가 자동으로 추가된다.
//		book_id bigint unique,
//		...
//	)
//	테이블이 만들어진 후 아래와 같이 book_id 라는 외래키 필드는 book 테이블의 기본키 id를
//	참조하는 외래키가 설정된다.
//	alter table if exists book_review_info add constraint FKp5fhkokpbtoxmc3mxo8ay9e5l 
//		foreign key (book_id) references book
	
//	@OneToOne 어노테이션에 optional = false 옵션을 지정하면 아래와 같이 create sql 명령이 
//	실행되며 테이블이 만들어진다.
//	@OneToOne(optional = false)
//	create table book_review_info (
//		...
//		자동으로 추가된 외래키 필드(book_id)가 null 값을 허용하지 않으므로 내부적으로 inner join이
//		걸려서 두 테이블에 모두 존재하는 값만 얻어온다.
//		테이블을 만들때 외래키로 사용될 필드가 자동으로 추가된다.
//		book_id bigint not null unique,
//		...
//	)
	
//	BookReviewInfo 엔티티에서 Book 엔티티를 직접 참조하게 설정할 것이므로 참조할 Book 엔티티
//	객체를 선언한다.
//	book_review_info 테이블에는 book_id 라는 필드가 만들어진다.
	private Book book;
	
}




