package com.tjoeun.springBootJPA.domain;

import com.tjoeun.springBootJPA.repository.MemberHistoryRepository;
import com.tjoeun.springBootJPA.support.BeanUtils;

import jakarta.persistence.PostPersist;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

public class MemberHistoryListener {

//	@PrePersist, @PreUpdate 어노테이션은 각각 insert, update 명령 실행전에 실행된다.
//	@PrePersist
//	@PreUpdate
//	insert, update 명령 실행후에 실행되도록 @PostPersist, @PostUpdate 어노테이션으로 수정한다.
	@PostPersist
	@PostUpdate
	public void prePersistAndPreUpdate(Object object) {
		System.out.println("MemberHistoryListener 클래스의 prePersistAndPreUpdate() 메소드 실행");
		MemberHistoryRepository memberHistoryRepository = 
				BeanUtils.getBean(MemberHistoryRepository.class);
		
		if (object instanceof Member) {
			Member member = (Member) object;
			MemberHistory memberHistory = new MemberHistory();
			memberHistory.setUserId(member.getId());
			memberHistory.setName(member.getName());
			memberHistory.setEmail(member.getEmail());
			
//			N:1 연관 관계를 설정하기 위해 MemberHistory 엔티티에 추가한 Member 엔티티 객체에
//			데이터를 넣어준다.
			memberHistory.setMember(member);
			
			memberHistoryRepository.save(memberHistory);
		}
	}
	
}
