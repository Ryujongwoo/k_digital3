package com.tjoeun.springBootJPA.domain;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class MemberTest {

	@Test
	void test() {
		Member member = new Member();
		member.setName("홍길동");
		member.setEmail("a@a.com");
		member.setCreateAt(LocalDateTime.now());
		member.setUpdateAt(LocalDateTime.now());
		System.out.println("member: " + member);
		log.info("member: " + member);
		
		Member member2 = new Member("임꺽정", "b@b.com", "도적넘");
		member2.setCreateAt(LocalDateTime.now());
		member2.setUpdateAt(LocalDateTime.now());
		System.out.println("member2: " + member2);
		
		Member member3 = new Member(1L, "장길산", "c@c.com", "도적넘", "DATA", Gender.MALE, null);
		System.out.println("member3: " + member3);
		
		Member member4 = Member.builder()
			.email("d@d.com")
			.name("일지매")
			.build();
		System.out.println("member4: " + member4);
	}

}
