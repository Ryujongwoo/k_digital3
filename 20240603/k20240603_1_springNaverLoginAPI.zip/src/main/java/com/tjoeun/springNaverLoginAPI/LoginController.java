package com.tjoeun.springNaverLoginAPI;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.scribejava.core.model.OAuth2AccessToken;
import com.tjoeun.springNaverLoginAPI.oauth.NaverLoginBO;

@Controller
public class LoginController {

//	네이버 로그인 API를 사용하는 메소드가 작성된 클래스 객체를 선언하고 초기화 한다.
	private NaverLoginBO naverLoginBO;
	
	@Autowired
	public void setNaverLoginBO(NaverLoginBO naverLoginBO) {
		this.naverLoginBO = naverLoginBO;
	}
	
//	로그인 사용자 정보를 기억할 변수를 선언한다.
	private String apiResult;
	
//	로그인 버튼이 있는 페이지를 요청하는 메소드
	@RequestMapping("/login")
	public String login(Model model, HttpSession session) {
//		네이버 아이디로 인증 URL을 생성하기 위해서 NaverLoginBO 클래스의 getAuthorizationUrl() 메소드를 호출한다.
		String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
		System.out.println("네이버 로그인 인증 URL: " + naverAuthUrl);
		model.addAttribute("url", naverAuthUrl);
		return "login";
	}

//	네이버 로그인 성공시 callback을 요청하는 메소드
	@RequestMapping("/callback")
	public String callback(Model model, HttpSession session, @RequestParam String code, 
			@RequestParam String state) throws IOException, ParseException {
		System.out.println("---------------- 네이버 로그인 callback ----------------");
		OAuth2AccessToken accessToken = naverLoginBO.getAccessToken(session, code, state);
		
//		로그인 사용자 정보를 읽어온다.
		apiResult = naverLoginBO.getUserProfile(accessToken); // String 형태의 json 데이터
//		System.out.println("apiResult: " + apiResult);
		
//		String 형식인 json 데이터를 json으로 바꾼다.
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(apiResult);
		
//		json 데이터를 파싱한다.
		JSONObject response = (JSONObject) jsonObject.get("response");
//		System.out.println("response: " + response);
//		System.out.println("birthday: " + response.get("birthday"));
//		System.out.println("mobile: " + response.get("mobile"));
//		System.out.println("name: " + response.get("name"));
//		System.out.println("id: " + response.get("id"));
//		System.out.println("email: " + response.get("email"));
		
//		파싱한 값을 세션에 저장한다.
		session.setAttribute("sessionId", response); // 세션 생성
		model.addAttribute("result", apiResult);
		
		return "naverSuccess";
	}
	
//	로그아웃 메소드
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		System.out.println("---------------- 네이버 로그아웃 ----------------");
		session.invalidate(); // 세션을 종료한다.
		return "redirect:login";
	}
	
}









