package com.tjoeun.springNaverLoginAPI.oauth;

import com.github.scribejava.core.builder.api.DefaultApi20;

//	네이버 로그인 API를 사용하기 위해 DefaultApi20 추상 클래스를 상속받아 적당한 클래스를 만든다.
public class NaverLoginApi extends DefaultApi20 {

	protected NaverLoginApi() {
		
	}
	
	private static class InstanceHolder {
		private static final NaverLoginApi INSTANCE = new NaverLoginApi();
	}
	
	public static NaverLoginApi instance() {
		return InstanceHolder.INSTANCE;
	}
	
	@Override
	public String getAccessTokenEndpoint() {
		return "https://nid.naver.com/oauth2.0/token?grant_type=authorization_code";
	}

	@Override
	protected String getAuthorizationBaseUrl() {
		return "https://nid.naver.com/oauth2.0/authorize";
	}

}
