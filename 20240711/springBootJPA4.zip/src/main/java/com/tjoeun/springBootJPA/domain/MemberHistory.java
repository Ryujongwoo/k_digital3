package com.tjoeun.springBootJPA.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
//	Auditable 인터페이스는 BaseEntity 클래스에 구현된 것을 상속받아 사용할 것이므로
//	Auditable 인터페이스 구현 부분을 제거한다.
public class MemberHistory extends BaseEntity /* implements Auditable */ {

	@Id
//	@GeneratedValue
//	id 값을 MYSQL, MariaDB와 같이 auto_increment를 이용해서 증가하게 한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long userId;
	private String name;
	private String email;
	
}





