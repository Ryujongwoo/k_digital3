package com.tjoeun.springBootJPA.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tjoeun.springBootJPA.domain.Book;

@SpringBootTest
class BookRepositoryTest {

	@Autowired
	private BookRepository bookRepository;
	
	@Test
	void test() {
		System.out.println("BookRepositoryTest 클래스의 test() 메소드 실행");
		
		System.out.println("@PrePersist 엔티티 이벤트 테스트 ============================================");
		Book book = new Book();
		book.setName("간지나는 springBoot 책");
//		book.setAuthor("홍길동");
		book.setCategory("springBoot");
		book.setAuthorId(10L);
		book.setPublisherId(20L);
		bookRepository.save(book);
		
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		System.out.println("=============================================================================");

	}

}
