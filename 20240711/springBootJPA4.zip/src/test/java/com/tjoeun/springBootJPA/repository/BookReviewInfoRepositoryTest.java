package com.tjoeun.springBootJPA.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tjoeun.springBootJPA.domain.Book;
import com.tjoeun.springBootJPA.domain.BookReviewInfo;

import jakarta.transaction.Transactional;

@SpringBootTest
class BookReviewInfoRepositoryTest {

	@Autowired
	private BookRepository bookRepository;
	@Autowired
	private BookReviewInfoRepository bookReviewInfoRepository;
	
	@Test
	void test() {
		System.out.println("BookReviewInfoRepositoryTest 클래스의 test() 메소드 실행");
		
//		책 정보를 입력한다.
		Book book = new Book();
		book.setName("간지나는 springBoot 책");
		book.setCategory("springBoot");
		book.setAuthorId(10L);
		book.setPublisherId(20L);
		bookRepository.save(book);
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		System.out.println("==================== book ====================");
		
//		리뷰 정보를 입력한다.
		BookReviewInfo bookReviewInfo = new BookReviewInfo();
		bookReviewInfo.setAverageReviewScore(4.5F); // float 타입이므로 숫자 뒤에 "F"를 붙여준다.
		bookReviewInfo.setReviewCount(2);
		bookReviewInfo.setBookIdx(1L);
		bookReviewInfoRepository.save(bookReviewInfo);
		List<BookReviewInfo> bookReviewInfos = bookReviewInfoRepository.findAll();
		bookReviewInfos.forEach(System.out::println);
		System.out.println("==================== book_review_info ====================");
		
//		RDBMS에서 수행하는 방식으로 테스트
//		리뷰 정보를 이용해서 책 정보를 얻어온다.
//		Book result = bookRepository.findById(1L).orElse(null);
		Book bookInfo = bookRepository.findById(
			bookReviewInfoRepository.findById(1L).orElse(null).getBookIdx()
		).orElse(null);
		System.out.println(bookInfo);
		System.out.println("==================== result ====================");
	}

	@Test
//	연관 관계 설정시 @Transactional 어노테이션을 사용하면 테스트가 제대로 진행되지 않을 수 있으니
//	테스트가 정상적으로 실행되지 않는다면 @Transactional을 제거하고 테스트 한다.
	@Transactional
	void oneToOneTest() {
		System.out.println("BookReviewInfoRepositoryTest 클래스의 oneToOneTest() 메소드 실행");
		System.out.println("BookReviewInfo 엔티티 정보에서 Book 엔티티 정보를 가져온다.");
		
		Book book = new Book();
		book.setName("간지나는 springBoot 책");
		book.setCategory("springBoot");
		book.setAuthorId(10L);
		book.setPublisherId(20L);
		bookRepository.save(book);
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		System.out.println("==================== book ====================");
		
		BookReviewInfo bookReviewInfo = new BookReviewInfo();
		bookReviewInfo.setAverageReviewScore(4.5F);
		bookReviewInfo.setReviewCount(2);
//		bookReviewInfo.setBookIdx(1L);
//		BookReviewInfo 정보와 1:1로 연관 관계를 가지는 Book 정보를 넣어준다.
		bookReviewInfo.setBook(book);
		bookReviewInfoRepository.save(bookReviewInfo);
		List<BookReviewInfo> bookReviewInfos = bookReviewInfoRepository.findAll();
		bookReviewInfos.forEach(System.out::println);
		System.out.println("==================== book_review_info ====================");

//		BookReviewInfo 정보에서 Book 정보를 얻어온다.
		Book result = bookReviewInfoRepository.findById(1L).orElse(null).getBook();
		System.out.println("result: " + result);
		System.out.println("==================== result ====================");
	}
	@Test
	@Transactional
	void oneToOneTest2() {
		System.out.println("BookReviewInfoRepositoryTest 클래스의 oneToOneTest2() 메소드 실행");
		System.out.println("Book 엔티티 정보에서 BookReviewInfo 엔티티 정보를 가져온다.");
		
		BookReviewInfo bookReviewInfo = new BookReviewInfo();
		bookReviewInfo.setAverageReviewScore(4.5F);
		bookReviewInfo.setReviewCount(2);
//		bookReviewInfo.setBookIdx(1L);
//		BookReviewInfo 정보와 1:1로 연관 관계를 가지는 Book 정보를 넣어준다.
//		bookReviewInfo.setBook(book);
		bookReviewInfoRepository.save(bookReviewInfo);
		List<BookReviewInfo> bookReviewInfos = bookReviewInfoRepository.findAll();
		bookReviewInfos.forEach(System.out::println);
		System.out.println("==================== book_review_info ====================");
		
		Book book = new Book();
		book.setName("간지나는 springBoot 책");
		book.setCategory("springBoot");
		book.setAuthorId(10L);
		book.setPublisherId(20L);
//		Book 정보와 1:1로 연관 관계를 가지는 BookReviewInfo 정보를 넣어준다.
		book.setBookReviewInfo(bookReviewInfo);
		bookRepository.save(book);
		List<Book> books = bookRepository.findAll();
		books.forEach(System.out::println);
		System.out.println("==================== book ====================");
		
//		Book 정보에서 BookReviewInfo 정보를 얻어온다.
		BookReviewInfo result = bookRepository.findById(1L).orElse(null).getBookReviewInfo();
		System.out.println("result: " + result);
		System.out.println("==================== result ====================");
	}
	
}










