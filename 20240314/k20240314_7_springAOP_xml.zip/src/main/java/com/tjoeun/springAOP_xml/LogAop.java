package com.tjoeun.springAOP_xml;

import org.aspectj.lang.ProceedingJoinPoint;

//	공통 기능 메소드를 모아놓은 클래스
public class LogAop {

//	before
	public void before() {
		System.out.println("LogAop 클래스의 before() 메소드가 실행됨");
	}
	
//	after-returning
	public void afterReturning() {
		System.out.println("LogAop 클래스의 afterReturning() 메소드가 실행됨");
	}
	
//	after-throwing
	public void afterThrowing() {
		System.out.println("LogAop 클래스의 afterThrowing() 메소드가 실행됨");
	}
	
//	after
	public void after() {
		System.out.println("LogAop 클래스의 after() 메소드가 실행됨");
	}
	
//	around
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("LogAop 클래스의 around() 메소드가 실행됨 - 핵심기능 실행 전");
		try {
			System.out.println("LogAop 클래스의 around() 메소드가 실행됨 - 핵심기능 실행 중");
			Object object = joinPoint.proceed();
			return object;
		} finally {
			System.out.println("LogAop 클래스의 around() 메소드가 실행됨 - 핵심기능 실행 후");
		}
	}
	
}




















