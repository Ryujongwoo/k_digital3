function alertTest() {
//	alert('단순한 메시지')
	alert('단순한 메시지를 출력하는 대화창')
}

function confirmTest() {
//	confirm('질문 메시지')
//	확인 버튼이 클릭되면 true, 취소 버튼이 클릭되면 false를 리턴한다.
	let result = confirm('브라우저 배경색을 바꿀래?')
	console.log(result)
	if (result) {
		document.body.style.backgroundColor = 'black'
		document.body.style.color = 'white'
	}
}

function promptTest() {
//	prompt('메시지')
//	prompt('메시지', '안내메시지')
//	확인 버튼을 클릭하면 입력한 문자열, 취소 버튼을 클릭하면 null을 리턴한다.
	let menu = prompt('점심은 뭘 먹을까요?\n(1.짜장면, 2.양장피, 3.팔보채)', '난 짜장면')
	console.log(menu)
	console.log(typeof menu)
	
	switch (menu) {
		case '1':
			console.log('짜장면')
			break
		case '2':
			console.log('양장피')
			break
		case '3':
			console.log('팔보채')
			break
		default:
			console.log('짜장면, 양장피, 팔보채 중에서 선택하세요.')
			break
	}
}

