//	명시적 함수
function func1() {
	alert('명시적 함수')
}

//	익명 함수
//	const func2 = function () {
//		alert('익명 함수')
//	}
const func2 = () => alert('익명 함수')

//	함수 리터럴
//	function func3() {
//		literalTest(function (msg) {
//			alert(msg)
//		})
//	}

function func3() {
	literalTest(msg => alert(msg))
}

function literalTest(literal) { // 인수로 함수가 넘어온다.
	literal('함수 리터럴 입니다.')
}

//	자바스크립트는 함수 오버로딩이 지원되지 않는다.
//	같은 이름의 함수를 다시 선언하면 이전에 선언했던 함수는 무시된다.
//	자바스크립트 함수는 실인수와 가인수의 개수가 다르더라도 정상적으로 실행된다.
//	함수가 호출될 때 넘어오는 인수를 저장할 변수가 모자라면 모자라는 대로 남으면 남는 대로 실행된다.
//	자바스크립트는 함수가 호출될 대 실인수는 arguments 객체로 먼저 전달되로 arguments 객체에 저장된
//	실인수를 가인수의 개수만큼 반복하며 arguments 객체에 저장된 데이터를 꺼내서 가인수에 넣어준다.

function varTest(a, b, c, d, e) {
//	console.log('varTest() 함수 실행')
	console.log(arguments)
	console.log(a)
	console.log(b)
	console.log(c)
	console.log(d)
	console.log(e)
	console.log('함수가 호출될 때 전달되는 데이터의 개수: ' + arguments.length)
	for (let i = 0; i<arguments.length; i++) {
		console.log(`arguments[${i}] = ${arguments[i]}`)
	}
}
























