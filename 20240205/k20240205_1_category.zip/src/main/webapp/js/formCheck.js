function mainFormCheck(obj) {
//	console.log(obj)
//	console.log(obj.category.value)
	if (!obj.category.value || obj.category.value.trim().length == 0) {
		alert('메인 카테고리는 반드시 입력해야 합니다.');
		obj.category.value = ''
		obj.category.focus()
		return false;
	}
	return true;
}

function subFormCheck(obj) {
	if (!obj.category.value || obj.category.value.trim().length == 0) {
		alert('서브 카테고리는 반드시 입력해야 합니다.');
		obj.category.value = ''
		obj.category.focus()
		return false;
	}
	return true;
}

//	==========================================================================================
//	$(document).ready(function () {
//	$(document).ready(() => {
$(() => {
//	alert('jQuery load')
//	메인 카테고리에 아무것도 입력되지 않았나 검사한다.
//	메인 카테고리를 입력하는 form은 1개만 있기 때문에 id를 지정해서 처리한다.


	$('#form').submit(function () {
		alert('메인 카테고리 폼에서 submit 버튼이 클릭됨')
	})
	
})






























