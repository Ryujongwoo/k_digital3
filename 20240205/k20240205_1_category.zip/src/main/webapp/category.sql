CREATE TABLE "CATEGORY" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"CATEGORY" VARCHAR2(100 BYTE) NOT NULL, 
	"GUP" NUMBER(*,0), 
	"LEV" NUMBER(*,0), 
	"SEQ" NUMBER(*,0), 
	 CONSTRAINT "CATEGORY_PK" PRIMARY KEY ("IDX")
);

DELETE FROM category;
DROP SEQUENCE category_idx_seq;
CREATE SEQUENCE category_idx_seq;

select * from category order by gup desc, seq asc;

























