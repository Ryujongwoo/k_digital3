package com.tjoeun.springBootBoard.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//	@Service 어노테이션을 붙여준 클래스는 springBoot가 자동으로 객체(bean)를 생성해 등록한다.
@Service
public class ArticleService {

	@Autowired
	private ArticleRepository articleRepository;
	
//	Article 테이블 전체 글 조회
	public List<Article> index() {
		log.info("ArticleService 클래스의 index() 메소드 실행");
		return articleRepository.findAll();
	}
	
//	Article 테이블 특정 글 조회
	public Article show(@PathVariable Long id) {
		log.info("ArticleService 클래스의 show() 메소드 실행");
		return articleRepository.findById(id).orElse(null);
	}

//	Article 테이블에 글 1건 저장
	public Article create(ArticleForm articleForm) {
		log.info("ArticleService 클래스의 create() 메소드 실행");
		log.info("articleForm = " + articleForm);
//		save() 메소드로 insert sql 명령을 실행할 때 id는 데이터베이스가 자동으로 생성하므로 id가
//		넘어오는 데이터는 테이블에 저장하지 않는다.
		Article article = articleForm.toEntity();
		if (article.getId() != null) {
			log.info("id가 null이 아니면 insert sql 명령을 실행하면 안됩니다.");
			return null;
		}
		return articleRepository.save(article);
	}
	
//	Article 테이블의 글 1건 수정
	public Article update(Long id, ArticleForm articleForm) {
		log.info("ArticleService 클래스의 update() 메소드 실행");
		log.info("id = {}, articleForm = {}", id, articleForm);
		Article article = articleForm.toEntity();
		Article target = articleRepository.findById(id).orElse(null);
		if (target == null || id != target.getId()) {
			log.info("잘못된 요청!!!");
			return null;
		}
		target.patch(article);
		return articleRepository.save(target);
	}
	
//	Article 테이블의 글 1건 삭제
	public Article delete(Long id) {
		log.info("ArticleService 클래스의 delete() 메소드 실행");
		Article target = articleRepository.findById(id).orElse(null);
		if (target == null) {
			log.info("잘못된 요청!!!");
			return null;
		}
		articleRepository.delete(target);
		return target;
	}

//	트랜잭션
//	@Transactional 어노테이션은 @Transactional 어노테이션을 지정한 메소드를 하나의 트랜잭션으로 묶는다.
//	@Transactional 어노테이션이 지정된 메소드가 정상적으로 실행되면 commit 되고 정상적으로 실행되지
//	않으면 rollback 된다.
	@Transactional
	public List<Article> createArticles(List<ArticleForm> articleForms) {
		log.info("ArticleService 클래스의 createArticles() 메소드 실행");
		log.info("articleForms = {}", articleForms);
		
//		articleForms(dto 묶음)에 저장된 데이터를 엔티티 묶음으로 변환한다.
		/*
		List<Article> articleList = new ArrayList<Article>();
		for (int i=0; i<articleForms.size(); i++) {
//			Article entity = articleForms.get(i).toEntity();
//			articleList.add(entity);
			articleList.add(articleForms.get(i).toEntity());
		}
		*/
//		ArticleForm 객체가 저장된 List를 stream으로 변환한 다음 Article 객체로 변환하고 Article 객체를
//		기억하는 List로 변환한다.
		List<Article> articleList = articleForms.stream()
				.map(entity -> entity.toEntity())
				.collect(Collectors.toList());
		log.info("articleList = {}", articleList);
		
//		엔티티 묶음을 Article 테이블에 저장한다.
//		for (Article entity : articleList) {
//			articleRepository.save(entity);
//		}
		articleList.stream().forEach(article -> articleRepository.save(article));
		
//		강제 예외 발생
		articleRepository.findById(-1L).orElseThrow(
			() -> new IllegalArgumentException("저장 실패!!!")
		);
		
		return articleList;
	}
	
}
















